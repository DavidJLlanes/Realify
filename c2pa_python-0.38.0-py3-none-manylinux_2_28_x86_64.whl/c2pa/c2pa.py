# Copyright 2025 Adobe. All rights reserved.
# This file is licensed to you under the Apache License,
# Version 2.0 (http://www.apache.org/licenses/LICENSE-2.0)
# or the MIT license (http://opensource.org/licenses/MIT),
# at your option.

# Unless required by applicable law or agreed to in writing,
# this software is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR REPRESENTATIONS OF ANY KIND, either express or
# implied. See the LICENSE-MIT and LICENSE-APACHE files for the
# specific language governing permissions and limitations under
# each license.

# Version: 0.38.0

import contextlib
import ctypes
import enum
import functools
import json
import logging
import sys
import os
import threading
import warnings
import weakref
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Optional, Union, Callable, Any, overload
import io
from .lib import dynamically_load_library, record_owner_pid, is_foreign_process
import mimetypes
from itertools import count

# Create a module-specific logger
logger = logging.getLogger("c2pa")
logger.addHandler(logging.NullHandler())

# Define required function names
_REQUIRED_FUNCTIONS = [
    # Version
    'c2pa_version',
    # Error retriever and parser
    'c2pa_error',
    # Legacy APIs, deprecated
    'c2pa_load_settings',
    # Stream
    'c2pa_create_stream',
    'c2pa_release_stream',
    # Reader bindings
    'c2pa_reader_from_stream',
    'c2pa_reader_from_manifest_data_and_stream',
    'c2pa_reader_json',
    'c2pa_reader_detailed_json',
    'c2pa_reader_crjson',
    'c2pa_reader_resource_to_stream',
    'c2pa_reader_from_context',
    'c2pa_reader_with_stream',
    'c2pa_reader_with_fragment',
    'c2pa_reader_with_manifest_data_and_stream',
    'c2pa_reader_is_embedded',
    'c2pa_reader_remote_url',
    'c2pa_reader_supported_mime_types',
    # Builder bindings
    'c2pa_builder_from_json',
    'c2pa_builder_from_archive',
    'c2pa_builder_set_no_embed',
    'c2pa_builder_set_remote_url',
    'c2pa_builder_set_intent',
    'c2pa_builder_add_resource',
    'c2pa_builder_add_ingredient_from_stream',
    'c2pa_builder_add_action',
    'c2pa_builder_to_archive',
    'c2pa_builder_write_ingredient_archive',
    'c2pa_builder_add_ingredient_from_archive',
    'c2pa_builder_sign',
    'c2pa_builder_sign_context',
    'c2pa_builder_from_context',
    'c2pa_builder_with_definition',
    'c2pa_builder_with_archive',
    'c2pa_builder_supported_mime_types',
    'c2pa_format_embeddable',
    # Signer bindings
    'c2pa_signer_create',
    'c2pa_signer_from_info',
    'c2pa_signer_reserve_size',
    'c2pa_ed25519_sign',
    'c2pa_signature_free',
    # Settings bindings
    'c2pa_settings_new',
    'c2pa_settings_set_value',
    'c2pa_settings_update_from_string',
    # Context bindings
    'c2pa_context_builder_new',
    'c2pa_context_builder_set_settings',
    'c2pa_context_builder_build',
    'c2pa_context_builder_set_signer',
    'c2pa_context_new',
    # Free bindings
    'c2pa_string_free',
    'c2pa_free_string_array',
    'c2pa_manifest_bytes_free',
    'c2pa_free',
]


def _validate_library_exports(lib):
    """Validate that all required functions are present in the loaded library.

    This validation is crucial for several security and reliability reasons:

    1. Security:
       - Prevents loading of libraries that might be missing critical functions
       - Ensures the library has expected functionality before code execution
       - Helps detect tampered or incomplete libraries

    2. Reliability:
       - Fails fast if the library is incomplete or corrupted
       - Prevents runtime errors from missing functions
       - Ensures all required functionality is available before use

    3. Version Compatibility:
       - Helps detect version mismatches where the library
          doesn't have all expected functions
       - Prevents partial functionality that could lead to undefined behavior
       - Ensures the library matches the expected API version

    Args:
        lib: The loaded library object

    Raises:
        ImportError: If any required function is missing,
                    with a detailed message listing
                    the missing functions. This helps diagnose issues
                    with the library installation or version compatibility.
    """
    missing_functions = []
    for func_name in _REQUIRED_FUNCTIONS:
        if not hasattr(lib, func_name):  # pragma: no cover
            missing_functions.append(func_name)

    if missing_functions:  # pragma: no cover
        raise ImportError(
            f"Library is missing required function symbols: "
            f"{', '.join(missing_functions)}\n"
            "This could indicate an incomplete or corrupted library "
            "installation or a version mismatch between the library "
            "and this Python wrapper."
        )


# Determine the library name based on the platform
if sys.platform == "win32":  # pragma: no cover
    _lib_name_default = "c2pa_c.dll"
elif sys.platform == "darwin":  # pragma: no cover
    _lib_name_default = "libc2pa_c.dylib"
else:  # pragma: no cover
    _lib_name_default = "libc2pa_c.so"

# Check for C2PA_LIBRARY_NAME environment variable
env_lib_name = os.environ.get("C2PA_LIBRARY_NAME")
if env_lib_name:  # pragma: no cover
    # Use the environment variable library name
    _lib = dynamically_load_library(env_lib_name)
else:
    # Use the platform-specific name
    _lib = dynamically_load_library(_lib_name_default)

_validate_library_exports(_lib)


class C2paSeekMode(enum.IntEnum):
    """Seek mode for stream operations."""
    START = 0
    CURRENT = 1
    END = 2


class C2paSigningAlg(enum.IntEnum):
    """Supported signing algorithms."""
    ES256 = 0
    ES384 = 1
    ES512 = 2
    PS256 = 3
    PS384 = 4
    PS512 = 5
    ED25519 = 6


class C2paDigitalSourceType(enum.IntEnum):
    """List of possible digital source types."""
    EMPTY = 0
    TRAINED_ALGORITHMIC_DATA = 1
    DIGITAL_CAPTURE = 2
    COMPUTATIONAL_CAPTURE = 3
    NEGATIVE_FILM = 4
    POSITIVE_FILM = 5
    PRINT = 6
    HUMAN_EDITS = 7
    COMPOSITE_WITH_TRAINED_ALGORITHMIC_MEDIA = 8
    ALGORITHMICALLY_ENHANCED = 9
    DIGITAL_CREATION = 10
    DATA_DRIVEN_MEDIA = 11
    TRAINED_ALGORITHMIC_MEDIA = 12
    ALGORITHMIC_MEDIA = 13
    SCREEN_CAPTURE = 14
    VIRTUAL_RECORDING = 15
    COMPOSITE = 16
    COMPOSITE_CAPTURE = 17
    COMPOSITE_SYNTHETIC = 18


class C2paBuilderIntent(enum.IntEnum):
    """Builder intent enumeration.
    """
    CREATE = 0  # New digital creation with specified digital source type
    EDIT = 1    # Edit of a pre-existing parent asset
    UPDATE = 2  # Restricted version of Edit for non-editorial changes


class LifecycleState(enum.IntEnum):
    """Internal state for lifecycle management.
    Object transitions: UNINITIALIZED -> ACTIVE -> CLOSED
    """
    UNINITIALIZED = 0
    ACTIVE = 1
    CLOSED = 2


class ManagedResource:
    """Base class for objects that hold a native (C FFI) resource.
    This is an internal base class that provides lifecycle management
    for native resources (e.g. pointers).

    Subclasses must:
      - Call `_activate(handle)` once the native pointer is created and
        validated, which takes ownership of it and marks the resource active.
        Never assign `self._handle` or `self._lifecycle_state` directly.
      - Call `_consume_and_swap(ffi_call, message)` when an FFI call consumes
        the current handle and returns a replacement.
      - Call `_teardown(free_handle=False)` when an FFI call took ownership of
        the handle without returning a replacement: the new owner frees it,
        so this does not.
      - Call `_release_handle()` when a consuming FFI call fails with ownership
        unknown: it frees eagerly (guarded), then closes. `_consume_and_swap`
        uses it on that failure path.
      - Override `_release()` to free class-specific resources
        (streams, caches, callbacks, etc.), called before the
        native pointer is freed.
      - Override `_init_attrs()` to set the class's own attributes to their
        defaults, and call it from `__init__`. `_wrap_native_handle` calls it
        too, so an instance built around an existing handle is never missing
        the attributes the rest of the class reads.

    The native pointer is freed automatically via `_free_native_ptr`.
    """

    _inflight = 0
    _mut_inflight = 0
    _pending_teardown: Optional[bool] = None
    _released = False

    def _init_attrs(self):
        """Set this class's own attributes to their defaults.

        Called by __init__ and by _wrap_native_handle, which bypasses
        __init__. Keeping the defaults here means an instance built around an
        existing handle is never missing what the rest of the class reads.
        """

    def __init__(self):
        self._lifecycle_state = LifecycleState.UNINITIALIZED
        self._handle = None
        self._op_lock = threading.RLock()
        self._inflight = 0
        self._mut_inflight = 0
        self._pending_teardown = None
        self._teardown_lock = threading.Lock()
        self._released = False
        record_owner_pid(self)

    def _live_op_lock(self):
        """Return this resource's operation lock, for mutual exclusion.

        Reentrant: a finalizer can run at any bytecode boundary, including
        inside a region this thread already locked, and a consuming call
        tears the handle down from inside the locked region.

        Falls back to a fresh lock when the attribute is missing.

        Never hold this across a native call that drives stream callbacks
        (construction, resource_to_stream, the Builder stream methods,
        signing).
        Those calls release the Global Interpreter Lock (GIL)
        and re-enter caller-supplied Python code, which may call back into
        this API on another thread.

        Raises in a forked child instead of returning the lock: a child
        inherits it in whatever state it had at fork(), and no thread in
        the child exists to release it, so acquiring there hangs forever.
        The child's copy is as unusable as a closed resource, so it
        reports the same error.
        """
        if is_foreign_process(self):
            raise C2paError(f"{type(self).__name__} is closed")

        lock = getattr(self, '_op_lock', None)
        if lock is None:
            lock = threading.RLock()
            try:
                self._op_lock = lock
            except Exception:
                pass
        return lock

    def _live_teardown_lock(self):
        """Lock to protect teardowns.

        Held only for plain attribute updates, never across a native call or
        an acquisition of the operation lock, so it can be taken either alone
        or inside the operation lock without an ordering cycle.

        Falls back to a fresh lock when the attribute is missing.
        """
        lock = getattr(self, '_teardown_lock', None)
        if lock is None:
            lock = threading.Lock()
            try:
                self._teardown_lock = lock
                lock = self._teardown_lock
            except Exception:
                pass
        return lock

    def _ensure_not_borrowed(self):
        """Raise if any native call, shared or mutating, is in flight on
        this handle, ensuring exclusive mutating calls.

        Raises:
            C2paError: If a native call is in flight on this resource.
        """
        if self._inflight > 0:
            raise C2paError(
                f"{type(self).__name__} is in use by another operation")

    def _ensure_no_mutating_call(self):
        """Raise if a mutating native call is in flight on this handle.

        Raises:
            C2paError: when a mutating native call is in progress.
        """
        if self._mut_inflight > 0:
            raise C2paError(
                f"{type(self).__name__} is running a mutating operation")

    @contextlib.contextmanager
    def _guarded_op(self, *, refuse_mut=True, exclusive=False):
        """Hold this resource's operation lock its duration,
        and mark this thread as inside a native-error section.

        Note: the native section opens first
        for the native call and closes last.

        Never hold this across a native call that drives stream callbacks.
        Those calls release the Global Interpreter Lock
        and re-enter caller-supplied code, which may call back into this API
        on another thread.
        """
        with _native_section():
            try:
                with self._live_op_lock():
                    if exclusive:
                        self._ensure_not_borrowed()
                        self._mut_inflight += 1
                        self._inflight += 1
                        try:
                            yield
                        finally:
                            self._mut_inflight -= 1
                            self._inflight -= 1
                    else:
                        if refuse_mut:
                            self._ensure_no_mutating_call()
                        yield
            finally:
                self._maybe_flush_pending()

    def _begin_reservation(self, *, mutating, refuse):
        """Count a native call as in flight, or raise.

        Only place counters go up.
        `refuse` runs under the lock, before counting,
        and raises to reject the call.
        """
        try:
            with self._live_op_lock():
                self._ensure_valid_state()
                refuse()
                if mutating:
                    self._mut_inflight += 1
                self._inflight += 1
        except BaseException:
            self._maybe_flush_pending()
            raise

    def _end_reservation(self, *, mutating):
        """Uncount a _begin_reservation() call and run any queued teardown.
        The only place the counters go down."""
        with self._live_op_lock():
            if mutating:
                self._mut_inflight -= 1
            self._inflight -= 1
        self._maybe_flush_pending()

    @contextlib.contextmanager
    def _reserve(self, *, mutating, refuse):
        """Hold a reservation across a native call.
        The lock is not held across the call itself:
        the call may run caller-supplied reentrant callbacks.
        A teardown that arrives meanwhile queues until
        the last call out.
        """
        self._begin_reservation(mutating=mutating, refuse=refuse)
        try:
            with _native_section():
                yield
        finally:
            self._end_reservation(mutating=mutating)

    @contextlib.contextmanager
    def _native_call(self):
        """Reserve the handle for a shared call:
        other shared calls may run alongside it, no mutating call may."""
        with self._reserve(mutating=False,
                           refuse=self._ensure_no_mutating_call):
            yield

    @contextlib.contextmanager
    def _exclusive_native_call(self):
        """Reserve the handle for a mutating call:
        no other call, shared or mutating, may run alongside it."""
        with self._reserve(mutating=True,
                           refuse=self._ensure_not_borrowed):
            yield

    @staticmethod
    def _free_native_ptr(ptr):
        """Free a native pointer by passing it to c2pa_free.

        c2pa_free's argtype is c_void_p, so ctypes converts any pointer
        instance directly. (ctypes.cast(ptr, c_void_p) would do the same
        conversion but leaves a reference cycle behind on every call.)

        Returns c2pa_free's status code:
        0 when the pointer was really freed,
        -1 when the pointer registry rejected an already-consumed address.
        A -1 can be expected on the eager-free path when the candidate released
        native memory has already dropped the value, and is gracefully handled by
        the native lib.
        """
        result = _lib.c2pa_free(ptr)
        if result != 0:
            logger.debug(
                "c2pa_free returned %s for an untracked pointer",
                result)
            _write_no_error_marker()
        return result

    def _ensure_valid_state(self):
        """Raise if the resource is closed or uninitialized."""
        name = type(self).__name__
        if self._lifecycle_state == LifecycleState.CLOSED:
            raise C2paError(f"{name} is closed")
        if self._lifecycle_state != LifecycleState.ACTIVE:
            raise C2paError(f"{name} is not properly initialized")
        if not self._handle:
            raise C2paError(
                f"{name} has an invalid internal state (active but no handle)")

    def _release(self):
        """Override to free class-specific resources (streams, caches, etc.).

        Called during cleanup before the native handle is freed.
        The default implementation does nothing.
        """

    def _safe_release(self):
        """Run _release(), logging on error.
        """
        try:
            self._release()
        except Exception:
            logger.error(
                "Failed to release %s resources",
                type(self).__name__,
                exc_info=True,
            )

    def _teardown(self, free_handle: bool):
        """Close the object: run _release, optionally free the handle, null it.
        free_handle=False (consumed) frees nothing, the new owner needs to free.

        The state change runs under the operation lock; _release and the
        free run after the lock is released.
        Deferred when any gate is blocking:
        - this resource's own handle is in flight in a native call
        - this thread is inside a native-error section for some call
        - someone else holds the operation lock (free intent gets queued)

        The forked-child case is handled before the lock is taken, because
        _live_op_lock() raises in a child: this path has to finish rather
        than report an error, so it cannot rely on acquiring.
        """
        if is_foreign_process(self):
            self._detach_in_child()
            return

        if self._released:
            return
        self._record_pending_intent(free_handle)

        lock = self._live_op_lock()
        if not lock.acquire(blocking=False):
            self._close_lifecycle()
            if _in_native_section():
                _register_for_section_flush(self)
            return

        detached = None
        try:
            if self._released:
                # Checks released as it recorded possible free intents.
                return
            if self._inflight > 0 or _in_native_section():
                self._close_lifecycle()
                if _in_native_section():
                    _register_for_section_flush(self)
                return

            with self._live_teardown_lock():
                pending = self._pending_teardown
                if pending is not None:
                    free_handle = pending and free_handle
                    self._pending_teardown = None
            detached = self._detach_for_teardown(free_handle)
        finally:
            lock.release()
        if detached is not None:
            self._finish_teardown(*detached)

    def _record_pending_intent(self, free_handle: bool):
        """Queue a teardown intent, leaving the resource usable until
        the intent runs.
        A queued consume wins over a free, since native already owns a
        consumed handle: freeing it again corrupts memory, where a missed
        free only leaks.
        """
        with self._live_teardown_lock():
            if self._released:
                return
            pending = self._pending_teardown
            if pending is None:
                self._pending_teardown = free_handle
            else:
                self._pending_teardown = pending and free_handle

    def _close_lifecycle(self):
        """Close the resource so it can no longer be used."""
        with self._live_teardown_lock():
            self._lifecycle_state = LifecycleState.CLOSED

    def _record_pending_teardown(self, free_handle: bool):
        """Record a teardown intent and queue it.
        Also closes the resource, and a queued consume wins
        over a (new) teardown request.
        """
        self._record_pending_intent(free_handle)
        self._close_lifecycle()

    def _detach_in_child(self):
        """In a forked child:
        null this copy's handle and mark it closed, without freeing.
        The parent still owns the native pointer.
        """
        if hasattr(self, '_handle'):
            self._handle = None
        if hasattr(self, '_lifecycle_state'):
            self._lifecycle_state = LifecycleState.CLOSED

    def _detach_for_teardown(self, free_handle: bool):
        """Mark the resource released and closed, and take its handle.
        Called under the operation lock. Returns (handle, free_handle) for
        _finish_teardown, or None when there is nothing left to do.
        """
        if is_foreign_process(self):
            self._detach_in_child()
            return None

        with self._live_teardown_lock():
            if self._released:
                return None
            self._released = True
            self._pending_teardown = None
            self._lifecycle_state = LifecycleState.CLOSED
        handle, self._handle = self._handle, None
        return handle, free_handle

    def _finish_teardown(self, handle, free_handle: bool):
        """Run _release, then free the detached handle if requested.
        Called after the operation lock is released.
        """
        self._safe_release()
        if free_handle and handle:
            try:
                ManagedResource._free_native_ptr(handle)
            except Exception:
                logger.error("Failed to free native %s resources",
                             type(self).__name__, exc_info=True)

    def _has_pending_teardown(self) -> bool:
        """Check if a teardown request is waiting for the resource."""
        return self._pending_teardown is not None

    def _flush_pending_pass(self):
        """Attempt to run pending teardowns."""
        if self._pending_teardown is None:
            return

        with self._live_op_lock():
            if self._pending_teardown is None:
                return
            if self._inflight > 0:
                return
            if _in_native_section():
                _register_for_section_flush(self)
                return
            with self._live_teardown_lock():
                free_handle = self._pending_teardown
                self._pending_teardown = None
            detached = self._detach_for_teardown(free_handle)
        if detached is not None:
            self._finish_teardown(*detached)

    def _maybe_flush_pending(self):
        """Recheck if a teardown can run after something
        that blocked it cleared."""
        if is_foreign_process(self):
            return

        self._flush_pending_pass()
        if self._has_pending_teardown() and not self._released:
            self._flush_pending_pass()

    def _release_handle(self):
        """Free this handle and close the object, unless a queued teardown
        already owns the free. Used only where ownership is unknown
        (a guarded free is a real free if ours, a no-op if not).
        Nulling the handle under a queued teardown would leave it nothing
        to free.
        """
        with self._live_op_lock():
            owned_elsewhere = self._pending_teardown is not None
            if not owned_elsewhere and (
                    self._lifecycle_state != LifecycleState.ACTIVE):
                self._handle = None
                self._lifecycle_state = LifecycleState.CLOSED
                owned_elsewhere = True
        if owned_elsewhere:
            self._maybe_flush_pending()
            return
        self._teardown(free_handle=True)

    def _activate(self, handle):
        """Attach a native handle to self and mark it active.
        Ownership of `handle` transfers here.

        Args:
            handle: Non-null native pointer to take ownership of

        Raises:
            C2paError: If the handle is null,
                or the resource is not uninitialized
        """
        name = type(self).__name__
        # A rejected activation must leave the object as it was.
        if not handle:
            raise C2paError(f"{name}: cannot activate a null handle")
        if self._lifecycle_state != LifecycleState.UNINITIALIZED:
            raise C2paError(
                f"{name}: already activated "
                f"({self._lifecycle_state.name})")

        self._handle = handle
        self._lifecycle_state = LifecycleState.ACTIVE

    def _create_and_activate(self, ffi_call, error_message, *,
                             check=lambda r: not r):
        """Get a new pointer/handle, validate, take ownership.

        Args:
            ffi_call: Zero-arg callable returning a fresh native pointer.
            error_message: Message for the C2paError raised on failure.
            check: Lambda determining result invalidity.

        Raises:
            C2paError: If the pointer fails the validation step.
        """
        ptr = None
        try:
            with _native_section():
                ptr = ffi_call()
                _check_ffi_operation_result(ptr, error_message, check=check)
            self._activate(ptr)
        except Exception:
            if ptr:
                ManagedResource._free_native_ptr(ptr)
            raise
        return ptr

    # Errors set by native lib, hinting at the cause of the error
    # These errors here means the pointer got somehow rejected by the lib,
    # so it is still ours to deal with.
    _PRE_CONSUME_ERROR_TAGS = (
        "UntrackedPointer:",
        "WrongPointerType:",
        "PointerInUse:",
        "ForeignProcess:",
    )

    # An error tag starts the message or follows this one wrapper.
    _NATIVE_ERROR_WRAPPER = "Other: "

    @staticmethod
    def _is_pre_consume_rejection(error: str) -> bool:
        """True when native rejected the handle before taking ownership.

        Anchored, not a substring search: native quotes caller text verbatim,
        so a tag mid-message describes the caller's input.

        The tags are the errors `untrack` in c2pa-rs
        c2pa_c_ffi/src/cimpl/utils.rs returns before it removes the handle's
        registry entry.
        """
        body = error
        if body.startswith(ManagedResource._NATIVE_ERROR_WRAPPER):
            body = body[len(ManagedResource._NATIVE_ERROR_WRAPPER):]
        return any(body.startswith(tag)
                   for tag in ManagedResource._PRE_CONSUME_ERROR_TAGS)

    def _invoke_consume(self, ffi_call, error_message, *, reserved=False):
        """Run an FFI call that consumes this handle, returning its raw result.

        A marshalling ArgumentError is re-raised untouched (call never reached
        native, handle unchanged). An Exception frees the handle before
        raising. The caller inspects the returned result to tell success
        from failure (the convention differs per call) and routes a failure
        to _raise_consume_failure.

        Args:
            ffi_call: Callable taking the current handle, returning the native
                result (a replacement pointer, a status code, ...).
            error_message: Format string with one placeholder, used to wrap a
                callback exception.
            reserved: True when the caller reserved the handle with
                _begin_consume(), which frees here rather than through
                _release_handle().

        Raises:
            ctypes.ArgumentError: If marshalling failed; handle untouched.
            C2paError: If the call raised any other exception.
        """
        # Same thread that makes the call, same thread-local slot.
        _write_no_error_marker()
        try:
            return ffi_call(self._handle)
        except ctypes.ArgumentError:
            # Marshalling failed: the call never reached native, so the handle
            # is untouched and still ours. Re-raise as-is.
            raise
        except Exception as e:
            if reserved:
                self._teardown(free_handle=True)
            else:
                self._release_handle()
            raise C2paError(error_message.format(e)) from e

    def _raise_consume_failure(self, error_message, *, reserved: bool):
        """Raise the error from an FFI handler consuming call.

        The native error is read before any free so a free's own
        pointer-tracking error cannot overwrite it.
        The native error slot is sticky and thread-local,
        and the native SDK does not clear it before the call.
        _invoke_consume marks the slot as carrying no error right before a
        consuming call, so a failure that sets no error of its own reads back
        as no error rather than as a stale one left by an earlier call.

        A caller that reserved the handle with _begin_consume() passes
        reserved=True (in-flight mark).

        Args:
            error_message: Format string with one placeholder, used when the
                native layer offers no error of its own.
            reserved: True when the caller reserved this handle with
                _begin_consume().

        Raises:
            C2paError: Always; typed by the native error when there is one.
        """
        error = _read_native_error()
        if error:
            if ManagedResource._is_pre_consume_rejection(error):
                logger.warning(
                    "%s: native call rejected the handle before taking "
                    "ownership (%s); handle retained",
                    type(self).__name__,
                    error)
                _raise_typed_c2pa_error(error)

            # A non-tag error means the native side took ownership then failed,
            # dropping the value itself: mark consumed, do not free (a free here
            # would be a guarded no-op that dirties the error slot and races a
            # recycled address in other threads).
            self._teardown(free_handle=False)
            _raise_typed_c2pa_error(error)

        # No error of its own: ownership is unknown, so free defensively.
        # c2pa_free returns -1 for an address native already reclaimed.
        if reserved:
            self._teardown(free_handle=True)
        else:
            self._release_handle()
        raise C2paError(error_message.format("Unknown error"))

    def _begin_consume(self):
        """Reserve this handle exclusively for a consuming call, or raise.
        The resource stays ACTIVE while being consumed.
        A teardown (deferred while the consume is in flight) closes it.

        Raises:
            C2paError: Unusable resource or native call in progress.
        """
        self._begin_reservation(mutating=True,
                                refuse=self._ensure_not_borrowed)

    def _end_consume(self):
        """Release a _begin_consume() reservation, then run any teardown
        that arrived while it was held."""
        self._end_reservation(mutating=True)

    def _consume_and_swap(self, ffi_call, error_message):
        """Run an FFI call consuming the handle, reserving it.
        A replacement handle swaps in on success
        (a returned null value is a failure).
        """
        def swap(new_ptr):
            with self._live_op_lock():
                self._handle = new_ptr

        self._consume_reserved(ffi_call, error_message,
                               succeeded=bool, on_success=swap)

    def _consume_reserved(self, ffi_call, error_message, *, succeeded,
                          on_success=None):
        """Run a reserved consuming call, then act on success.

        Args:
            succeeded: Reads the call's raw result and returns whether it
                succeeded. Each entry point has its own convention: a status
                code, or a replacement pointer.
            on_success: Called with the raw result on success. Default:
                mark the handle consumed, closed, not freed.

        Returns:
            The call's raw result, for callers that hand it on.
        """
        self._begin_consume()
        try:
            with _native_section():
                result = self._invoke_consume(
                    ffi_call, error_message, reserved=True)
                if succeeded(result):
                    if on_success is None:
                        self._teardown(free_handle=False)
                    else:
                        on_success(result)
                    return result
                self._raise_consume_failure(error_message, reserved=True)
        finally:
            self._end_consume()

    def _consume_no_replacement(self, ffi_call, error_message):
        """Run an FFI call that consumes this handle on success, when the native
        call returns a status code (0 = success) rather than a replacement
        handle. A non-zero status is a failure routed to
        _raise_consume_failure.
        """
        self._consume_reserved(
            ffi_call, error_message,
            succeeded=lambda status: status == 0)

    def _consume_into(self, ffi_call, error_message):
        """Run an FFI call that consumes this handle and returns a *different*
        object's pointer. On success this handle is consumed (mark, don't free)
        and the new pointer is returned for the caller to own. A null return is
        a failure routed to _raise_consume_failure.
        """
        # A null pointer is falsy.
        return self._consume_reserved(
            ffi_call, error_message,
            succeeded=lambda pointer: bool(pointer))

    @classmethod
    def _wrap_native_handle(cls, handle):
        """Build a brand-new instance around an already-valid,
        already-owned native handle (bypassing __init__).

        Everything an instance needs besides the native handle must be set in
        `_init_attrs()`. `_wrap_native_handle` never runs `__init__`.
        An attribute a subclass sets only in `__init__` will be
        missing (or left at its `_init_attrs` default) on a wrapped instance.

        Ownership of `handle` transfers only on successful return. If this
        raises, the caller still owns the pointer and must free it.

        Args:
            handle: Non-null native pointer to take ownership of

        Raises:
            C2paError: If the handle is null
        """
        obj = object.__new__(cls)
        ManagedResource.__init__(obj)
        obj._init_attrs()
        obj._activate(handle)
        return obj

    def _cleanup_resources(self):
        """Release native resources idempotently."""
        try:
            if is_foreign_process(self):
                self._detach_in_child()
                return
            if hasattr(self, '_lifecycle_state'):
                # Closes here must defer to the teardown checks.
                self._teardown(free_handle=True)
        except Exception:
            pass

    @property
    def is_valid(self) -> bool:
        """Is the resource usable now?
        ACTIVE, holding a handle, or a shared borrow,
        and no mutating (exclusive) or consuming native call in progress."""
        return (
            self._lifecycle_state == LifecycleState.ACTIVE
            and self._handle is not None
            and self._mut_inflight == 0
            and not is_foreign_process(self)
        )

    def close(self) -> None:
        """Release the resource (idempotent, never raises)."""
        self._cleanup_resources()

    def __enter__(self):
        """For classes with context manager (with) pattern"""
        self._ensure_valid_state()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """For classes with context manager (with) pattern"""
        self.close()

    def __del__(self):
        """Free native resources if close() was not called."""
        self._cleanup_resources()


# Mapping from C2paSigningAlg enum to string representation,
# as the enum value currently maps by default to an integer value.
_ALG_TO_STRING_BYTES_MAPPING = {
    C2paSigningAlg.ES256: b"es256",
    C2paSigningAlg.ES384: b"es384",
    C2paSigningAlg.ES512: b"es512",
    C2paSigningAlg.PS256: b"ps256",
    C2paSigningAlg.PS384: b"ps384",
    C2paSigningAlg.PS512: b"ps512",
    C2paSigningAlg.ED25519: b"ed25519",
}


# Define callback types
ReadCallback = ctypes.CFUNCTYPE(
    ctypes.c_ssize_t,
    ctypes.c_void_p,
    ctypes.POINTER(
        ctypes.c_uint8),
    ctypes.c_ssize_t)
SeekCallback = ctypes.CFUNCTYPE(
    ctypes.c_ssize_t,
    ctypes.c_void_p,
    ctypes.c_ssize_t,
    ctypes.c_int)

# Additional callback types
WriteCallback = ctypes.CFUNCTYPE(
    ctypes.c_ssize_t,
    ctypes.c_void_p,
    ctypes.POINTER(
        ctypes.c_uint8),
    ctypes.c_ssize_t)
FlushCallback = ctypes.CFUNCTYPE(ctypes.c_ssize_t, ctypes.c_void_p)
SignerCallback = ctypes.CFUNCTYPE(
    ctypes.c_ssize_t, ctypes.c_void_p, ctypes.POINTER(
        ctypes.c_ubyte), ctypes.c_size_t, ctypes.POINTER(
            ctypes.c_ubyte), ctypes.c_size_t)


class StreamContext(ctypes.Structure):
    """Opaque structure for stream context."""
    _fields_ = []  # Empty as it's opaque in the C API


class C2paSigner(ctypes.Structure):
    """Opaque structure for signer context."""
    _fields_ = []  # Empty as it's opaque in the C API


class C2paStream(ctypes.Structure):
    """A C2paStream is a Rust Read/Write/Seek stream that can be created in C.

    This class represents a low-level stream interface that bridges Python
    and Rust/C code. It implements the Rust Read/Write/Seek traits in C,
    allowing for efficient data transfer between Python and the C2PA library
    without unnecessary copying.

    The stream is used for various operations including:
    - Reading manifest data from files
    - Writing signed content to files
    - Handling binary resources
    - Managing ingredient data

    The structure contains function pointers that implement stream operations:
    - reader: Function to read data from the stream
    - seeker: Function to change the stream position
    - writer: Function to write data to the stream
    - flusher: Function to flush any buffered data

    This is a critical component for performance as it allows direct memory
    access between Python and the C2PA library without intermediate copies.
    """
    _fields_ = [
        # Opaque context pointer for the stream
        ("context", ctypes.POINTER(StreamContext)),
        # Function to read data from the stream
        ("reader", ReadCallback),
        # Function to change stream position
        ("seeker", SeekCallback),
        # Function to write data to the stream
        ("writer", WriteCallback),
        # Function to flush buffered data
        ("flusher", FlushCallback),
    ]


# Address passed to c2pa_free to plant a marker in the native error slot.
# 2 is not an allocatable address.
_NO_ERROR_MARKER_ADDR = 2


@functools.lru_cache(maxsize=1)
def _marker_text_for(pid):
    """Learn the marker text once per process ID."""
    return _learn_no_error_marker_text()


def _marker_text():
    """Marker text for this process, or None if it could not be learned."""
    return _marker_text_for(os.getpid())


def _write_no_error_marker():
    """A c2pa_free of an address the registry does not track writes
    an expected error message learned on first use into the
    thread-local error slot and returns -1.

    This marker mechanism exists to distinguish a consuming call that
    failed without setting its own error from a stale message left
    by an earlier call on the same thread.

    No-op when the marker text could not be learned on first use.
    """
    if _marker_text() is None:
        return
    _lib.c2pa_free(_NO_ERROR_MARKER_ADDR)


def _is_no_error_marker(message: str) -> bool:
    """True for the marker meaning "no current error of our own"."""
    return message == _marker_text()


def _read_native_error() -> Optional[str]:
    """Read the last error from the native library, or None if unset.

    The slot is marked as carrying no error before returning, so a
    given error is reported once, by the caller that observes it. The native
    slot is thread-local and sticky, so a message left in place stays readable
    indefinitely and is available to be reported again by a later,
    unrelated call that failed without setting an error of its own
    (or a missing clear of an error slot).
    """
    error = _lib.c2pa_error()
    if not error:
        # NULL means the message could not be rendered, not that the slot
        # is empty, so it still has to be marked.
        _write_no_error_marker()
        return None
    try:
        message = ctypes.string_at(error).decode('utf-8')
    finally:
        _lib.c2pa_string_free(error)

    _write_no_error_marker()
    if not message or _is_no_error_marker(message):
        return None
    return message


_native_section_state = threading.local()


def _in_native_section() -> bool:
    """True while this thread is between an FFI call and reading back the
    native error it may have set (see _native_section())."""
    return getattr(_native_section_state, 'depth', 0) > 0


def _register_for_section_flush(resource):
    """Record that `resource`'s teardown was deferred only because this
    thread's native-error section was open."""
    pending = getattr(_native_section_state, 'pending_resources', None)
    if pending is not None:
        pending.append(resource)


@contextlib.contextmanager
def _native_section():
    """Mark this thread as inside a section where a native call's result is
    about to be read back: an error-slot check, or a consuming call's
    success/failure classification.

    Reentrant: a nested native call on the same thread nests.
    """
    state = _native_section_state
    depth = getattr(state, 'depth', 0)
    state.depth = depth + 1
    if depth == 0:
        state.pending_resources = []

    def _drain():
        """Flush every deferred resource. Returns the first error raised."""
        pending, state.pending_resources = state.pending_resources, []
        first_error = None
        for resource in pending:
            try:
                resource._maybe_flush_pending()
            except BaseException as e:  # noqa: BLE001
                if first_error is None:
                    first_error = e
        return first_error

    try:
        yield
    except BaseException:
        state.depth -= 1
        if state.depth == 0:
            drain_error = _drain()
            if drain_error is not None:
                logger.error(
                    "Deferred teardown failed while unwinding: %s",
                    drain_error)
        raise
    else:
        state.depth -= 1
        if state.depth == 0:
            drain_error = _drain()
            if drain_error is not None:
                logger.error(
                    "Deferred teardown failed: %s", drain_error)


class C2paSignerInfo(ctypes.Structure):
    """Configuration for a Signer."""
    _fields_ = [
        ("alg", ctypes.c_char_p),
        ("sign_cert", ctypes.c_char_p),
        ("private_key", ctypes.c_char_p),
        ("ta_url", ctypes.c_char_p),
    ]

    def __init__(self, alg, sign_cert, private_key, ta_url):
        """Initialize C2paSignerInfo with optional parameters.

        Args:
            alg: The signing algorithm, either as a
            C2paSigningAlg enum or string or bytes
            (will be converted accordingly to bytes for native library use)
            sign_cert: The signing certificate as a string
            private_key: The private key as a string
            ta_url: The timestamp authority URL as bytes, or None for no
            timestamp authority.
        """

        if sign_cert is None:
            raise ValueError("sign_cert must be set")
        if private_key is None:
            raise ValueError("private_key must be set")

        # Handle alg parameter: can be C2paSigningAlg enum
        # or string (or bytes), convert as needed
        if isinstance(alg, C2paSigningAlg):
            # Convert enum to string representation
            alg_str = _ALG_TO_STRING_BYTES_MAPPING.get(alg)
            if alg_str is None:
                raise ValueError(f"Unsupported signing algorithm: {alg}")
            alg = alg_str
        elif isinstance(alg, str):
            # String to bytes, as requested by native lib
            _check_cstr_arg("alg", alg)
            alg = alg.encode('utf-8')
        elif isinstance(alg, bytes):
            # In bytes already
            pass
        else:
            raise TypeError(
                f"alg must be C2paSigningAlg enum, string, or bytes, "
                f"got {type(alg)}"
            )

        # Handle ta_url parameter:
        # allow None, string or bytes, convert string to bytes as needed
        if ta_url is None:
            # NULL is how the native side spells "no timestamp authority".
            pass
        elif isinstance(ta_url, str):
            # String to bytes, as requested by native lib
            _check_cstr_arg("ta_url", ta_url)
            ta_url = ta_url.encode('utf-8')
        elif isinstance(ta_url, bytes):
            # In bytes already
            pass
        else:
            raise TypeError(
                f"ta_url must be None, string or bytes, got {type(ta_url)}"
            )

        # Call parent constructor with processed values
        super().__init__(alg, sign_cert, private_key, ta_url)


class C2paReader(ctypes.Structure):
    """Opaque structure for reader context."""
    _fields_ = []  # Empty as it's opaque in the C API


class C2paBuilder(ctypes.Structure):
    """Opaque structure for builder context."""
    _fields_ = []  # Empty as it's opaque in the C API


class C2paSettings(ctypes.Structure):
    """Opaque structure for settings context."""
    _fields_ = []  # Empty as it's opaque in the C API


class C2paContextBuilder(ctypes.Structure):
    """Opaque structure for context builder."""
    _fields_ = []  # Empty as it's opaque in the C API


class C2paContext(ctypes.Structure):
    """Opaque structure for context."""
    _fields_ = []  # Empty as it's opaque in the C API

# Helper function to set function prototypes


def _setup_function(func, argtypes, restype=None):
    func.argtypes = argtypes
    func.restype = restype


# Set up function prototypes (some may need the types defined above)
_setup_function(_lib.c2pa_create_stream,
                [ctypes.POINTER(StreamContext),
                 ReadCallback,
                 SeekCallback,
                 WriteCallback,
                 FlushCallback],
                ctypes.POINTER(C2paStream))

# Add release_stream prototype
_setup_function(
    _lib.c2pa_release_stream,
    [ctypes.POINTER(C2paStream)],
    None
)

# Set up function prototypes not attached to an API object
_setup_function(_lib.c2pa_version, [], ctypes.c_void_p)
_setup_function(_lib.c2pa_error, [], ctypes.c_void_p)
_setup_function(_lib.c2pa_string_free, [ctypes.c_void_p], None)
_setup_function(
    _lib.c2pa_load_settings, [
        ctypes.c_char_p, ctypes.c_char_p], ctypes.c_int)
_setup_function(
    _lib.c2pa_free_string_array,
    [ctypes.POINTER(ctypes.c_char_p), ctypes.c_size_t],
    None
)

# Set up Reader function prototypes
_setup_function(_lib.c2pa_reader_from_stream,
                [ctypes.c_char_p, ctypes.POINTER(C2paStream)],
                ctypes.POINTER(C2paReader))
_setup_function(
    _lib.c2pa_reader_from_manifest_data_and_stream, [
        ctypes.c_char_p, ctypes.POINTER(C2paStream), ctypes.POINTER(
            ctypes.c_ubyte), ctypes.c_size_t], ctypes.POINTER(C2paReader))
_setup_function(
    _lib.c2pa_reader_json, [
        ctypes.POINTER(C2paReader)], ctypes.c_void_p)
_setup_function(
    _lib.c2pa_reader_detailed_json, [
        ctypes.POINTER(C2paReader)], ctypes.c_void_p)
_setup_function(
    _lib.c2pa_reader_crjson, [
        ctypes.POINTER(C2paReader)], ctypes.c_void_p)
_setup_function(_lib.c2pa_reader_resource_to_stream, [ctypes.POINTER(
    C2paReader), ctypes.c_char_p, ctypes.POINTER(C2paStream)], ctypes.c_int64)
_setup_function(
    _lib.c2pa_reader_supported_mime_types,
    [ctypes.POINTER(ctypes.c_size_t)],
    ctypes.POINTER(ctypes.c_char_p)
)
_setup_function(
    _lib.c2pa_reader_is_embedded,
    [ctypes.POINTER(C2paReader)],
    ctypes.c_bool
)
_setup_function(
    _lib.c2pa_reader_remote_url,
    [ctypes.POINTER(C2paReader)],
    ctypes.c_void_p
)

# Set up Builder function prototypes
_setup_function(
    _lib.c2pa_builder_from_json, [
        ctypes.c_char_p], ctypes.POINTER(C2paBuilder))
_setup_function(_lib.c2pa_builder_from_archive,
                [ctypes.POINTER(C2paStream)],
                ctypes.POINTER(C2paBuilder))
_setup_function(
    _lib.c2pa_builder_with_archive,
    [ctypes.POINTER(C2paBuilder), ctypes.POINTER(C2paStream)],
    ctypes.POINTER(C2paBuilder))
_setup_function(_lib.c2pa_builder_set_no_embed, [
                ctypes.POINTER(C2paBuilder)], None)
_setup_function(
    _lib.c2pa_builder_set_remote_url, [
        ctypes.POINTER(C2paBuilder), ctypes.c_char_p], ctypes.c_int)
_setup_function(
    _lib.c2pa_builder_set_intent,
    [ctypes.POINTER(C2paBuilder), ctypes.c_uint, ctypes.c_uint],
    ctypes.c_int)
_setup_function(_lib.c2pa_builder_add_resource, [ctypes.POINTER(
    C2paBuilder), ctypes.c_char_p, ctypes.POINTER(C2paStream)], ctypes.c_int)
_setup_function(_lib.c2pa_builder_add_ingredient_from_stream,
                [ctypes.POINTER(C2paBuilder),
                 ctypes.c_char_p,
                 ctypes.c_char_p,
                 ctypes.POINTER(C2paStream)],
                ctypes.c_int)
_setup_function(_lib.c2pa_builder_add_action,
                [ctypes.POINTER(C2paBuilder), ctypes.c_char_p],
                ctypes.c_int)
_setup_function(_lib.c2pa_builder_to_archive,
                [ctypes.POINTER(C2paBuilder), ctypes.POINTER(C2paStream)],
                ctypes.c_int)
_setup_function(_lib.c2pa_builder_write_ingredient_archive,
                [ctypes.POINTER(C2paBuilder),
                 ctypes.c_char_p,
                 ctypes.POINTER(C2paStream)],
                ctypes.c_int)
_setup_function(_lib.c2pa_builder_add_ingredient_from_archive,
                [ctypes.POINTER(C2paBuilder),
                 ctypes.POINTER(C2paStream)],
                ctypes.c_int)
_setup_function(_lib.c2pa_builder_sign,
                [ctypes.POINTER(C2paBuilder),
                 ctypes.c_char_p,
                 ctypes.POINTER(C2paStream),
                 ctypes.POINTER(C2paStream),
                 ctypes.POINTER(C2paSigner),
                 ctypes.POINTER(ctypes.POINTER(ctypes.c_ubyte))],
                ctypes.c_int64)
_setup_function(
    _lib.c2pa_manifest_bytes_free, [
        ctypes.POINTER(
            ctypes.c_ubyte)], None)
_setup_function(
    _lib.c2pa_format_embeddable, [
        ctypes.c_char_p, ctypes.POINTER(
            ctypes.c_ubyte), ctypes.c_size_t, ctypes.POINTER(
                ctypes.POINTER(
                    ctypes.c_ubyte))], ctypes.c_int64)
_setup_function(_lib.c2pa_signer_create,
                [ctypes.c_void_p,
                 SignerCallback,
                 ctypes.c_int,
                 ctypes.c_char_p,
                 ctypes.c_char_p],
                ctypes.POINTER(C2paSigner))
_setup_function(_lib.c2pa_signer_from_info,
                [ctypes.POINTER(C2paSignerInfo)],
                ctypes.POINTER(C2paSigner))

# Set up Signer function prototypes
_setup_function(
    _lib.c2pa_signer_reserve_size, [
        ctypes.POINTER(C2paSigner)], ctypes.c_int64)
_setup_function(
    _lib.c2pa_ed25519_sign, [
        ctypes.POINTER(
            ctypes.c_ubyte), ctypes.c_size_t, ctypes.c_char_p], ctypes.POINTER(
                ctypes.c_ubyte))
_setup_function(
    _lib.c2pa_signature_free, [
        ctypes.POINTER(
            ctypes.c_ubyte)], None)
_setup_function(
    _lib.c2pa_builder_supported_mime_types,
    [ctypes.POINTER(ctypes.c_size_t)],
    ctypes.POINTER(ctypes.c_char_p)
)

# Set up Settings function prototypes
_setup_function(_lib.c2pa_settings_new, [], ctypes.POINTER(C2paSettings))
_setup_function(
    _lib.c2pa_settings_set_value,
    [ctypes.POINTER(C2paSettings), ctypes.c_char_p, ctypes.c_char_p],
    ctypes.c_int
)
_setup_function(
    _lib.c2pa_settings_update_from_string,
    [ctypes.POINTER(C2paSettings), ctypes.c_char_p, ctypes.c_char_p],
    ctypes.c_int
)

# Set up ContextBuilder function prototypes
_setup_function(
    _lib.c2pa_context_builder_new,
    [],
    ctypes.POINTER(C2paContextBuilder)
)
_setup_function(
    _lib.c2pa_context_builder_set_settings,
    [ctypes.POINTER(C2paContextBuilder), ctypes.POINTER(C2paSettings)],
    ctypes.c_int
)
_setup_function(
    _lib.c2pa_context_builder_build,
    [ctypes.POINTER(C2paContextBuilder)],
    ctypes.POINTER(C2paContext)
)

# Set up Context function prototypes
_setup_function(_lib.c2pa_context_new, [], ctypes.POINTER(C2paContext))
_setup_function(
    _lib.c2pa_reader_from_context,
    [ctypes.POINTER(C2paContext)],
    ctypes.POINTER(C2paReader)
)
_setup_function(
    _lib.c2pa_reader_with_stream,
    [ctypes.POINTER(C2paReader), ctypes.c_char_p,
     ctypes.POINTER(C2paStream)],
    ctypes.POINTER(C2paReader)
)
_setup_function(
    _lib.c2pa_reader_with_manifest_data_and_stream,
    [ctypes.POINTER(C2paReader), ctypes.c_char_p,
     ctypes.POINTER(C2paStream),
     ctypes.POINTER(ctypes.c_ubyte), ctypes.c_size_t],
    ctypes.POINTER(C2paReader),
)
_setup_function(
    _lib.c2pa_reader_with_fragment,
    [ctypes.POINTER(C2paReader), ctypes.c_char_p,
     ctypes.POINTER(C2paStream), ctypes.POINTER(C2paStream)],
    ctypes.POINTER(C2paReader)
)
_setup_function(
    _lib.c2pa_builder_from_context,
    [ctypes.POINTER(C2paContext)],
    ctypes.POINTER(C2paBuilder)
)
_setup_function(
    _lib.c2pa_builder_with_definition,
    [ctypes.POINTER(C2paBuilder), ctypes.c_char_p],
    ctypes.POINTER(C2paBuilder)
)
_setup_function(_lib.c2pa_free, [ctypes.c_void_p], ctypes.c_int)


def _learn_no_error_marker_text():
    """Plant the marker once and read back the exact text the native lib
    produces for it, so equality checks match this build of the lib.
    Runs on first use in each process.

    No-op/None if the marker couldn't be learned.
    """
    _lib.c2pa_free(_NO_ERROR_MARKER_ADDR)
    raw = _lib.c2pa_error()
    if not raw:
        logger.warning(
            "c2pa: could not find out error marker")
        return None
    try:
        text = ctypes.string_at(raw).decode('utf-8')
    finally:
        _lib.c2pa_string_free(raw)
    if not text:
        logger.warning(
            "c2pa: error-slot marker not set, some errors may be stale")
        return None
    marker_hex = hex(_NO_ERROR_MARKER_ADDR)
    if marker_hex not in text:
        logger.warning(
            "c2pa: error-slot marker %s unclear, some errors may be stale",
            marker_hex)
        return None
    return text


_setup_function(
    _lib.c2pa_context_builder_set_signer,
    [ctypes.POINTER(C2paContextBuilder), ctypes.POINTER(C2paSigner)],
    ctypes.c_int
)
_setup_function(
    _lib.c2pa_builder_sign_context,
    [ctypes.POINTER(C2paBuilder),
     ctypes.c_char_p,
     ctypes.POINTER(C2paStream),
     ctypes.POINTER(C2paStream),
     ctypes.POINTER(ctypes.POINTER(ctypes.c_ubyte))],
    ctypes.c_int64
)


class C2paError(Exception):
    """Exception raised for C2PA errors.

    This is the base class for all C2PA exceptions. Catching C2paError will
    catch all typed C2PA exceptions (e.g., C2paError.ManifestNotFound).
    """

    def __init__(self, message: str = ""):
        self.message = message
        super().__init__(message)


# Define typed exception subclasses that inherit from C2paError
# These are attached to C2paError as class attributes for backward compatibility
# (eg., C2paError.ManifestNotFound), and also to ensure properly inheritance hierarchy

class _C2paAssertion(C2paError):
    """Exception raised for assertion errors."""
    pass


class _C2paAssertionNotFound(C2paError):
    """Exception raised when an assertion is not found."""
    pass


class _C2paDecoding(C2paError):
    """Exception raised for decoding errors."""
    pass


class _C2paEncoding(C2paError):
    """Exception raised for encoding errors."""
    pass


class _C2paFileNotFound(C2paError):
    """Exception raised when a file is not found."""
    pass


class _C2paIo(C2paError):
    """Exception raised for IO errors."""
    pass


class _C2paJson(C2paError):
    """Exception raised for JSON errors."""
    pass


class _C2paManifest(C2paError):
    """Exception raised for manifest errors."""
    pass


class _C2paManifestNotFound(C2paError):
    """
    Exception raised when a manifest is not found,
    aka there is no C2PA metadata to read
    aka there is no JUMBF data to read.
    """
    pass


class _C2paNotSupported(C2paError):
    """Exception raised for unsupported operations."""
    pass


class _C2paOther(C2paError):
    """Exception raised for other errors."""
    pass


class _C2paRemoteManifest(C2paError):
    """Exception raised for remote manifest errors."""
    pass


class _C2paResourceNotFound(C2paError):
    """Exception raised when a resource is not found."""
    pass


class _C2paSignature(C2paError):
    """Exception raised for signature errors."""
    pass


class _C2paVerify(C2paError):
    """Exception raised for verification errors."""
    pass


class _C2paUntrackedPointer(C2paError):
    """Exception raised when the native layer does not recognize a pointer.
    Raised when a consume-and-return call rejects the handle it was given
    before taking ownership of it, so the caller still owns that handle.
    """
    pass


class _C2paWrongPointerType(C2paError):
    """Exception raised when a pointer is tracked under a different type.
    Like _C2paUntrackedPointer, this is rejected before ownership transfer,
    so the caller still owns the handle it passed in.
    """
    pass


# Attach exception subclasses to C2paError for backward compatibility
# Preserves behavior for exception catching like except C2paError.ManifestNotFound,
# also reduces imports (think of it as an alias of sorts)
C2paError.Assertion = _C2paAssertion
C2paError.AssertionNotFound = _C2paAssertionNotFound
C2paError.Decoding = _C2paDecoding
C2paError.Encoding = _C2paEncoding
C2paError.FileNotFound = _C2paFileNotFound
C2paError.Io = _C2paIo
C2paError.Json = _C2paJson
C2paError.Manifest = _C2paManifest
C2paError.ManifestNotFound = _C2paManifestNotFound
C2paError.NotSupported = _C2paNotSupported
C2paError.Other = _C2paOther
C2paError.RemoteManifest = _C2paRemoteManifest
C2paError.ResourceNotFound = _C2paResourceNotFound
C2paError.Signature = _C2paSignature
C2paError.Verify = _C2paVerify
C2paError.UntrackedPointer = _C2paUntrackedPointer
C2paError.WrongPointerType = _C2paWrongPointerType


class _StringContainer:
    """Container class to hold encoded strings,
    and prevent them from being garbage collected.

    This class is used to store encoded strings
    that need to remain in memory while being used by C functions.
    The strings are stored as instance attributes,
    to prevent them from being garbage collected.

    This is an internal implementation detail
    and should not be used outside this module.
    """

    def __init__(self):
        """Initialize an empty string container."""
        self._path_str = ""
        self._data_dir_str = ""


if sys.implementation.name == "cpython":
    _PyMemoryView_FromMemory = ctypes.pythonapi.PyMemoryView_FromMemory
    _PyMemoryView_FromMemory.restype = ctypes.py_object
    _PyMemoryView_FromMemory.argtypes = (
        ctypes.c_void_p, ctypes.c_ssize_t, ctypes.c_int)
    _PyBUF_WRITE = 0x200

    def _write_buf(address, length):
        return _PyMemoryView_FromMemory(address, length, _PyBUF_WRITE)
else:
    def _write_buf(address, length):
        return (ctypes.c_char * length).from_address(address)


def _convert_to_py_string(value) -> str:
    if value is None:
        return ""

    py_string = ""

    # Validate and normalize pointer before reading and freeing.
    if isinstance(value, ctypes.c_void_p):
        address = value.value
    elif isinstance(value, int):
        address = value
    else:
        return ""
    if not address:
        return ""

    try:
        raw = ctypes.string_at(address)

        try:
            py_string = raw.decode('utf-8', errors='strict')
        except Exception:
            py_string = ""
        finally:
            # Only free if we have a valid pointer
            try:
                _lib.c2pa_string_free(value)
            except Exception:
                # Ignore clean up issues
                pass
    except (ctypes.ArgumentError, TypeError, ValueError, OSError):
        # Invalid pointer type or value, gracefully handled by native lib.
        try:
            _lib.c2pa_string_free(value)
        except Exception:
            pass
        return ""

    return py_string


def _check_cstr_arg(name: str, value) -> None:
    """Reject a string argument the native layer would refuse.
    Checking here keeps the rejection on this side of the boundary,
    where the handle is known to be untouched.

    Raises:
        C2paError: With same message the native layer would have produced.
    """
    if value is None:
        raise C2paError(f"NullParameter: {name}")

    embedded_nul = (
        '\x00' in value if isinstance(value, str) else b'\x00' in value)
    if embedded_nul:
        # ctypes truncates at the first NUL.
        raise C2paError(f"NullParameter: {name} contains a null byte")


def _check_handle_arg(name: str, handle) -> None:
    """Reject a null handle argument.
    Note: registry membership is not observable from Python,
    so a tracked-but-invalid pointer still reaches native.

    Raises:
        C2paError: With same message the native layer would have produced.
    """
    if not handle:
        raise C2paError(f"NullParameter: {name}")


def _check_bytes_arg(name: str, buffer) -> None:
    """Reject a byte buffer the native layer would refuse.

    Native rejects a null pointer and any size outside 1..=isize::MAX.
    An empty buffer reaches it as size 0.
    Checking here keeps the rejection on this side of the boundary,
    where the handle is known to be untouched.

    Raises:
        C2paError: With same message the native layer would have produced.
    """
    if buffer is None:
        raise C2paError(f"NullParameter: {name}")
    if len(buffer) == 0:
        raise C2paError(f"InvalidBufferSize: 0 for '{name}'")


def _raise_typed_c2pa_error(error_str: str) -> None:
    """Parse an error string and raise the appropriate typed C2paError.

    Error strings from the native library have the format "ErrorType: message".
    This function parses the error type and raises the corresponding
    C2paError subclass with the full original error string as the message.

    Args:
        error_str: The error string from the native library

    Raises:
        C2paError subclass: The appropriate typed exception based on error_str
    """
    # Error format from native library is "ErrorType: message" or "ErrorType message"
    # Try splitting on ": " first (colon-space), then fall back to space only
    if ': ' in error_str:
        parts = error_str.split(': ', 1)
    else:
        parts = error_str.split(' ', 1)
    if len(parts) > 1:
        error_type = parts[0]
        # Use the full error string as the message for backward compatibility
        if error_type == "Assertion":
            raise C2paError.Assertion(error_str)
        elif error_type == "AssertionNotFound":
            raise C2paError.AssertionNotFound(error_str)
        elif error_type == "Decoding":
            raise C2paError.Decoding(error_str)
        elif error_type == "Encoding":
            raise C2paError.Encoding(error_str)
        elif error_type == "FileNotFound":
            raise C2paError.FileNotFound(error_str)
        elif error_type == "Io":
            raise C2paError.Io(error_str)
        elif error_type == "Json":
            raise C2paError.Json(error_str)
        elif error_type == "Manifest":
            raise C2paError.Manifest(error_str)
        elif error_type == "ManifestNotFound":
            raise C2paError.ManifestNotFound(error_str)
        elif error_type == "NotSupported":
            raise C2paError.NotSupported(error_str)
        elif error_type == "Other":
            raise C2paError.Other(error_str)
        elif error_type == "RemoteManifest":
            raise C2paError.RemoteManifest(error_str)
        elif error_type == "ResourceNotFound":
            raise C2paError.ResourceNotFound(error_str)
        elif error_type == "Signature":
            raise C2paError.Signature(error_str)
        elif error_type == "Verify":
            raise C2paError.Verify(error_str)
        elif error_type == "UntrackedPointer":
            raise C2paError.UntrackedPointer(error_str)
        elif error_type == "WrongPointerType":
            raise C2paError.WrongPointerType(error_str)
    # If no recognized error type, raise base C2paError
    raise C2paError(error_str)


def _check_ffi_operation_result(
        result,
        fallback_msg,
        *,
        check=lambda r: not r):
    """Check an FFI native call result and raise C2paError if it indicates failure.

    Args:
        result: The return value from the FFI call
        fallback_msg: Error message if the native library has no error details.
            An error message template ending in `: {}` may be passed
            unformatted. An "Unknown error" fallback is filled in here, since
            reaching this point means the native layer offered nothing better.
            Plain messages with no placeholder are used as-is.
        check: Predicate that returns True when the result indicates failure.
            Defaults to `not r` (for pointer-returning calls).
            Use `lambda r: r != 0` for status-code-returning calls.
            Use `lambda r: r < 0` for signed-result calls.

    Returns:
        The result unchanged, if the check passed.

    Raises:
        C2paError: If the check indicates failure
    """
    if check(result):
        error = _read_native_error()
        if error:
            _raise_typed_c2pa_error(error)
        raise C2paError(fallback_msg.format("Unknown error"))
    return result


def _to_utf8_bytes(data: Union[str, dict],
                   error_context: str = "input") -> bytes:
    """Convert a string or dict to UTF-8 bytes.

    If data is a dict, it is serialized to JSON first.

    Args:
        data: String or dict to encode.
        error_context: Description for error messages.

    Returns:
        UTF-8 encoded bytes.

    Raises:
        C2paError.Json: If dict serialization fails.
        C2paError.Encoding: If UTF-8 encoding fails or data is not a supported type.
    """
    if isinstance(data, dict):
        try:
            data = json.dumps(data)
        except (TypeError, ValueError) as e:
            raise C2paError.Json(f"Failed to serialize {error_context}: {e}")
    if not isinstance(data, str):
        raise C2paError.Encoding(
            f"Expected str or dict for {error_context}, "
            f"got {type(data).__name__}")
    try:
        return data.encode('utf-8')
    except UnicodeError as e:
        raise C2paError.Encoding(f"Invalid UTF-8 in {error_context}: {e}")


def sdk_version() -> str:
    """
    Returns the underlying c2pa-rs/c2pa-c-ffi version string
    c2pa-rs and c2pa-c-ffi versions are in lockstep release,
    so the version string is the same for both and we return
    the shared semantic version number.
    """
    vstr = version()
    # Example: "c2pa-c/0.60.1 c2pa-rs/0.60.1"
    for part in vstr.split():
        if part.startswith("c2pa-rs/"):
            return part.split("/", 1)[1]
    # Fallback to full string n case format would change, eg. local builds
    return vstr  # pragma: no cover


def version() -> str:
    """
    Get the C2PA library version with the fully qualified names
    of the native core libraries (library names and semantic version
    numbers).
    """
    result = _lib.c2pa_version()
    return _convert_to_py_string(result)


@overload
def load_settings(settings: str, format: str = "json") -> None:
    ...


@overload
def load_settings(settings: dict) -> None:
    ...


def load_settings(settings: Union[str, dict], format: str = "json") -> None:
    """Load C2PA settings into thread-local storage from a string or dict.

    .. deprecated::
        Use :class:`Settings` and :class:`Context` for
        per-instance configuration instead. Settings and
        Context will propagate configurations through object instances,
        no thread-local configurations. Avoid mixing Context APIs
        and legacy load_settings usage.

    Args:
        settings: The settings string or dict to load
        format: The format of the settings string (default: "json").
                Ignored when settings is a dict.

    Raises:
        C2paError: If there was an error loading the settings
    """
    warnings.warn(
        "load_settings() is deprecated. Use Settings"
        " and Context for per-instance configuration.",
        DeprecationWarning,
        stacklevel=2,
    )

    # Convert to JSON string as necessary
    try:
        if isinstance(settings, dict):
            settings_str = json.dumps(settings)
            format = "json"
        else:
            settings_str = settings
    except (TypeError, ValueError) as e:
        raise C2paError(f"Failed to serialize settings to JSON: {e}")

    try:
        _check_cstr_arg("settings", settings_str)
        _check_cstr_arg("format", format)
        settings_bytes = settings_str.encode('utf-8')
        format_bytes = format.encode('utf-8')
    except (AttributeError, UnicodeEncodeError) as e:
        raise C2paError(f"Failed to encode settings to UTF-8: {e}")

    with _native_section():
        result = _lib.c2pa_load_settings(settings_bytes, format_bytes)
        _check_ffi_operation_result(
            result,
            "Error loading settings",
            check=lambda r: r != 0)


@contextlib.contextmanager
def _context_guard(context):
    """Hold a caller-supplied context valid across a native call.

    ContextProvider requires only is_valid and execution_context.
    A context that implements _native_call (a ManagedResource) is
    guarded through it instead.
    """
    native_call = getattr(context, "_native_call", None)
    if native_call is None:
        yield
        return
    with native_call():
        yield


class ContextProvider(ABC):
    """Abstract base class for types that provide a C2PA context.

    Subclass to implement a custom context provider.
    The built-in Context class is the standard implementation.

    A provider that does not derive from ManagedResource is used without
    in-flight teardown protection: closing it on another thread while a Reader
    or Builder is being constructed from it can free the native context while
    that construction is still using it.
    """

    @property
    @abstractmethod
    def is_valid(self) -> bool:
        """Whether a call using this provider would be accepted right now.

        Return True when the underlying native context is active, holds a
        handle, and has no mutating or consuming native call in flight.
        Return False after the provider has been closed or invalidated.
        The answer is a snapshot and does not keep the handle alive.

        The ManagedResource base class provides a standard
        implementation that checks lifecycle state, handle presence and
        the mutating in-flight count.
        """
        ...

    @property
    @abstractmethod
    def execution_context(self):
        """Return the raw native C2paContext pointer.

        The returned pointer must be valid for the duration of any
        FFI call that uses it. Callers should check is_valid before
        accessing this property.
        """
        ...


class Settings(ManagedResource):
    """Configuration for C2PA operations.

    Settings configure SDK behavior. Use with Context class to
    apply settings to Reader/Builder operations.
    """

    def __init__(self):
        """Create new Settings with default values."""
        super().__init__()

        self._create_and_activate(
            _lib.c2pa_settings_new, "Failed to create Settings")

    @classmethod
    def from_json(cls, json_str: str) -> 'Settings':
        """Create Settings from a serialized JSON configuration string.

        Args:
            json_str: JSON string with settings configuration.

        Returns:
            A new Settings instance with the given configuration.
        """
        settings = cls()
        settings.update(json_str)
        return settings

    @classmethod
    def from_dict(cls, config: dict) -> 'Settings':
        """Create Settings from a (JSON-based)dictionary.

        Args:
            config: Dictionary with settings configuration.

        Returns:
            A new Settings instance with the given configuration.
        """
        return cls.from_json(json.dumps(config))

    def set(self, path: str, value: str) -> 'Settings':
        """Set a configuration value by dot-notation path.

        Args:
            path: Dot-notation path (e.g. "builder.thumbnail.enabled").
            value: Value to set, as JSON string.

        Returns:
            self, for method chaining.

        Raises:
            C2paError: If path or value contains a null byte, or native
                rejects the path or the parsed value.
        """
        path_bytes = _to_utf8_bytes(path, "settings path")
        value_bytes = _to_utf8_bytes(value, "settings value")
        _check_cstr_arg("settings path", path_bytes)
        _check_cstr_arg("settings value", value_bytes)

        with self._guarded_op(exclusive=True):
            self._ensure_valid_state()

            _check_ffi_operation_result(
                _lib.c2pa_settings_set_value(
                    self._handle, path_bytes, value_bytes),
                "Failed to set settings value",
                check=lambda r: r != 0)

        return self

    def update(
        self, data: Union[str, dict],
    ) -> 'Settings':
        """Update current configuration from a JSON string or dict.
        If the updated string overwrite an existing settings value,
        the last setting value set for that property wins.

        Args:
            data: A JSON string or dict with configuration to merge.

        Returns:
            self, for method chaining.
        """
        data_bytes = _to_utf8_bytes(data, "settings data")
        _check_cstr_arg("settings data", data_bytes)

        with self._guarded_op(exclusive=True):
            self._ensure_valid_state()

            _check_ffi_operation_result(
                _lib.c2pa_settings_update_from_string(
                    self._handle, data_bytes, b"json"),
                "Failed to update settings",
                check=lambda r: r != 0)

        return self

    @property
    def _c_settings(self):
        """Expose the raw pointer for c2pa_context_builder_set_settings.
        """
        self._ensure_valid_state()
        return self._handle


class ContextBuilder:
    """Fluent builder for Context.

    Use Context.builder() to create an instance.
    """

    def __init__(self):
        self._settings = None
        self._signer = None

    def with_settings(
        self, settings: 'Settings',
    ) -> 'ContextBuilder':
        """Attach Settings to the Context being built.

        Can be called multiple times, but each call replaces
        the previous Settings object entirely (the last one wins).
        To merge multiple configurations, use Settings.update()
        on a single Settings instance before passing it in.

        Args:
            settings: The Settings instance to use.

        Returns:
            self, for method chaining.
        """
        self._settings = settings
        return self

    def with_signer(
        self, signer: 'Signer',
    ) -> 'ContextBuilder':
        """Attach a Signer (will be consumed on build)."""
        self._signer = signer
        return self

    def build(self) -> 'Context':
        """Build and return a configured Context."""
        return Context(
            settings=self._settings,
            signer=self._signer,
        )


class Context(ManagedResource, ContextProvider):
    """Per-instance context for C2PA operations.

    A Context may carry Settings and a Signer,
    and is passed to Reader or Builder to control their behavior,
    thus propagating settings and configurations by passing
    the Context object (+settings on it) as parameter.

    When a Signer is provided, the Signer object is consumed,
    as it becomes included into the Context, and must not be
    used directly again after that.
    """

    class _NativeContextBuilder(ManagedResource):
        """Wrapper so the context builder gets a lifecycle:
        a failure inside the `with` block frees via close()
        unless a consuming call already did.
        Wrapper should be short-lived.
        """

        def __init__(self):
            super().__init__()
            self._create_and_activate(
                _lib.c2pa_context_builder_new,
                "Failed to create ContextBuilder")

    def __init__(
        self,
        settings: Optional['Settings'] = None,
        signer: Optional['Signer'] = None,
    ):
        """Create a Context.

        Args:
            settings: Optional Settings for configuration.
                If None, default SDK settings are used.
            signer: Optional Signer. If provided it is consumed
                and must not be used directly again after that call.

        Raises:
            C2paError: If creation fails
        """
        super().__init__()
        self._init_attrs()

        if settings is None and signer is None:
            # Simple default context
            self._create_and_activate(
                _lib.c2pa_context_new,
                "Failed to create Context")
        else:
            # Any failure inside the with frees the builder via close();
            # a successful build consumes it, so close() is then a no-op.
            with self._NativeContextBuilder() as context_builder:
                if settings is not None:
                    with context_builder._guarded_op(exclusive=True), \
                            settings._native_call():
                        _check_ffi_operation_result(
                            _lib.c2pa_context_builder_set_settings(
                                context_builder._handle,
                                settings._c_settings),
                            "Failed to set settings on Context",
                            check=lambda r: r != 0)

                if signer is not None:
                    # Retain a rejected signer for later teardown.
                    self._signer_callback_cb = signer._callback_cb
                    _check_handle_arg('builder', context_builder._handle)
                    signer._consume_no_replacement(
                        lambda h: _lib.c2pa_context_builder_set_signer(
                            context_builder._handle, h),
                        "Failed to set signer on Context: {}")
                    self._has_signer = True

                context_ptr = context_builder._consume_into(
                    lambda h: _lib.c2pa_context_builder_build(h),
                    "Failed to build Context: {}")

            self._activate(context_ptr)

    def _init_attrs(self):
        super()._init_attrs()
        self._has_signer = False
        self._signer_callback_cb = None

    def _release(self):
        """Release Context-specific resources."""
        self._signer_callback_cb = None

    @classmethod
    def builder(cls) -> 'ContextBuilder':
        """Return a fluent ContextBuilder."""
        return ContextBuilder()

    @classmethod
    def from_json(
        cls,
        json_str: str,
        signer: Optional['Signer'] = None,
    ) -> 'Context':
        """Create Context from a JSON configuration string.

        Args:
            json_str: JSON string with settings config.
            signer: Optional Signer (consumed if provided).

        Returns:
            A new Context instance.
        """
        settings = Settings.from_json(json_str)
        try:
            return cls(settings=settings, signer=signer)
        finally:
            settings.close()

    @classmethod
    def from_dict(
        cls,
        config: dict,
        signer: Optional['Signer'] = None,
    ) -> 'Context':
        """Create Context from a dictionary.

        Args:
            config: Dictionary with settings configuration.
            signer: Optional Signer (consumed if provided).

        Returns:
            A new Context instance.
        """
        return cls.from_json(json.dumps(config), signer=signer)

    @property
    def has_signer(self) -> bool:
        """Whether this context was created with a signer."""
        return self._has_signer

    @property
    def execution_context(self):
        """Return the raw C2paContext pointer."""
        self._ensure_valid_state()
        return self._handle


class Stream:
    # Class-level somewhat atomic counter for generating
    #  unique stream IDs (useful for tracing streams usage in debug)
    _stream_id_counter = count(start=0, step=1)

    # Maximum value for a 32-bit signed integer (2^31 - 1)
    _MAX_STREAM_ID = 2**31 - 1

    # Methods an object must expose to be wrapped as Stream.
    _REQUIRED_STREAM_METHODS = ("read", "write", "seek", "tell", "flush")

    # Class-level error messages to avoid multiple creation
    _ERROR_MESSAGES = {
        'stream_error': "Error cleaning up stream: {}",
        'callback_error': "Error cleaning up callback {}: {}",
        'cleanup_error': "Error during cleanup: {}",
    }

    def __init__(self, file_like_stream):
        """Initialize a new Stream wrapper around a file-like object
        (or an in-memory stream).

        Args:
            file_like_stream: A file-like stream object or an in-memory stream
              that implements read, write, seek, tell, and flush methods

        Raises:
            TypeError: The file stream object doesn't
              implement all required methods
        """
        # Initialize _closed first to prevent AttributeError
        # during garbage collection
        self._closed = False
        self._initialized = False
        self._stream = None
        # Serializes close() and __del__ against a concurrent double-free.
        self._close_lock = threading.RLock()

        # Generate unique stream ID using object ID and counter
        stream_counter = next(Stream._stream_id_counter)

        # Handle counter overflow by resetting the counter
        if stream_counter >= Stream._MAX_STREAM_ID:  # pragma: no cover
            # Reset the counter to 0 and get the next value
            Stream._stream_id_counter = count(start=0, step=1)
            stream_counter = next(Stream._stream_id_counter)

        self._stream_id = f"{id(self)}-{stream_counter}"

        # Rest of the existing initialization code...
        missing_methods = [
            method for method in Stream._REQUIRED_STREAM_METHODS if not hasattr(
                file_like_stream, method)]
        if missing_methods:
            raise TypeError(
                "Object must be a stream-like object with methods: {}. "
                "Missing: {}".format(
                    ", ".join(Stream._REQUIRED_STREAM_METHODS),
                    ", ".join(missing_methods),
                )
            )

        self._file_like_stream = file_like_stream

        # Weakref breaks avoids references cycles:
        # Stream -> ctypes_cb -> closure -> Stream.
        _weak_self = weakref.ref(self)

        def read_callback(ctx, data, length):
            """Callback function for reading data from the Python stream.

            This function is called by C2PA library when it needs to read data.
            It handles:
            - Stream state validation
            - Memory safety
            - Error handling
            - Buffer management

            Args:
                ctx: The stream context (unused)
                data: Pointer to the buffer to read into
                length: Maximum number of bytes to read

            Returns:
                Number of bytes read, or -1 on error
            """
            s = _weak_self()
            if s is None:
                return -1
            if not s._initialized or s._closed:
                return -1
            try:
                if not data or length <= 0:
                    return -1

                stream = s._file_like_stream
                readinto = getattr(stream, "readinto", None)
                if readinto is not None:
                    # Most streams have readinto
                    buf = _write_buf(
                        ctypes.addressof(data.contents), length)
                    try:
                        n = readinto(buf)
                    finally:
                        release = getattr(buf, "release", None)
                        if release is not None:
                            release()
                    if not n:
                        return 0
                    if n > length:
                        raise ValueError(
                            f"readinto returned {n} bytes but buffer length is {length}"
                        )
                    return n

                # Fallback for streams without readinto.
                buffer = stream.read(length)
                if not buffer:  # EOF
                    return 0

                # Ensure we don't write beyond the allocated memory
                actual_length = min(len(buffer), length)
                # Direct memory copy
                ctypes.memmove(data, buffer, actual_length)

                return actual_length
            except Exception:
                return -1

        def seek_callback(ctx, offset, whence):
            """Callback function for seeking in the Python stream.

            This function is called by the C2PA library when it needs to change
            the stream position. It handles:
            - Stream state validation
            - Position validation
            - Error handling

            Args:
                ctx: The stream context (unused)
                offset: The offset to seek to
                whence: The reference point (0=start, 1=current, 2=end)

            Returns:
                New position in the stream, or -1 on error
            """
            s = _weak_self()
            if s is None:
                return -1
            file_stream = s._file_like_stream
            if not s._initialized or s._closed:
                return -1
            try:
                # Fall back to tell() only for stream objects that do not
                # return the new absolute position and return None.
                pos = file_stream.seek(offset, whence)
                return pos if pos is not None else file_stream.tell()
            except Exception:
                return -1

        def write_callback(ctx, data, length):
            """Callback function for writing data to the Python stream.

            This function is called by C2PA library when needing to write data.
            It handles:
            - Stream state validation
            - Memory safety
            - Error handling
            - Buffer management

            Args:
                ctx: The stream context (unused)
                data: Pointer to the data to write
                length: Number of bytes to write

            Returns:
                Number of bytes written, or -1 on error
            """
            s = _weak_self()
            if s is None:
                return -1
            if not s._initialized or s._closed:
                return -1
            try:
                if not data or length <= 0:
                    return -1

                s._file_like_stream.write(ctypes.string_at(data, length))
                return length
            except Exception:
                return -1

        def flush_callback(ctx):
            """Callback function for flushing the Python stream.

            This function is called by the C2PA library when it needs to ensure
            all buffered data is written. It handles:
            - Stream state validation
            - Error handling

            Args:
                ctx: The stream context (unused)

            Returns:
                0 on success, -1 on error
            """
            s = _weak_self()
            if s is None:
                return -1
            if not s._initialized or s._closed:
                return -1
            try:
                s._file_like_stream.flush()
                return 0
            except Exception:
                return -1

        # Create callbacks that will be kept alive by being instance attributes
        self._read_cb = ReadCallback(read_callback)
        self._seek_cb = SeekCallback(seek_callback)
        self._write_cb = WriteCallback(write_callback)
        self._flush_cb = FlushCallback(flush_callback)

        # Create the stream
        self._stream = _lib.c2pa_create_stream(
            None,
            self._read_cb,
            self._seek_cb,
            self._write_cb,
            self._flush_cb
        )
        if not self._stream:
            error = _read_native_error()
            raise C2paError(
                "Failed to create stream: {}".format(error or "Unknown error"))

        self._initialized = True
        record_owner_pid(self)

    def __enter__(self):
        """Context manager entry."""
        if not self._initialized:
            raise RuntimeError("Stream was not properly initialized")
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.close()

    def __del__(self):
        """Ensure resources are cleaned up if close()wasn't called.

        This destructor only cleans up if the object
        hasn't been explicitly closed.
        """
        try:
            if is_foreign_process(self):
                return
            lock = getattr(self, '_close_lock', None)
            if lock is not None and not lock.acquire(blocking=False):
                return
            try:
                # Only cleanup if not already closed and we have a valid stream
                if hasattr(self, '_closed') and not self._closed:
                    stream = self._stream
                    if hasattr(self, '_stream') and stream:
                        self._closed = True
                        self._initialized = False
                        try:
                            _lib.c2pa_release_stream(stream)
                        except Exception:
                            # Destructors shouldn't raise exceptions
                            logger.error("Failed to release Stream")
                            pass
                        finally:
                            self._stream = None
            finally:
                if lock is not None:
                    lock.release()
        except Exception:
            # Destructors must not raise exceptions
            pass

    def close(self):
        """Release the stream resources.

        This method ensures all resources are properly cleaned up,
        even if errors occur during cleanup.
        Errors during cleanup are logged but not raised to ensure cleanup.
        Multiple calls to close() are handled gracefully.
        Only the Stream's owner closes the stream.
        """
        # Checked before the lock, as _live_op_lock() and __del__ do:
        # a child inherits _close_lock in whatever state it had at fork(),
        # and the thread holding it does not exist there to release it.
        if is_foreign_process(self):
            self._closed = True
            self._initialized = False
            return

        # Serializes against __del__ / a concurrent close().
        with self._close_lock:
            if self._closed:
                return

            try:
                # Clean up stream first as it depends on callbacks
                # Note: We don't close self._file_like_stream as we don't
                # own it, the opener owns it.
                stream = self._stream
                if stream:
                    self._closed = True
                    self._initialized = False
                    try:
                        _lib.c2pa_release_stream(stream)
                    except Exception as e:
                        logger.error(
                            Stream._ERROR_MESSAGES['stream_error'].format(
                                str(e)))
                    finally:
                        self._stream = None

                # Clean up callbacks
                for attr in [
                        '_read_cb', '_seek_cb', '_write_cb', '_flush_cb']:
                    if hasattr(self, attr):
                        try:
                            setattr(self, attr, None)
                        except Exception as e:
                            logger.error(
                                Stream._ERROR_MESSAGES['callback_error']
                                .format(attr, str(e)))

            except Exception as e:
                logger.error(
                    Stream._ERROR_MESSAGES['cleanup_error'].format(
                        str(e)))
            finally:
                self._closed = True
                self._initialized = False

    def write_to_target(self, dest_stream):
        self._file_like_stream.seek(0)
        dest_stream.write(self._file_like_stream.getvalue())

    @property
    def closed(self) -> bool:
        """Check if the stream is closed.

        Returns:
            bool: True if the stream is closed, False otherwise
        """
        return self._closed

    @property
    def initialized(self) -> bool:
        """Check if the stream is properly initialized.

        Returns:
            bool: True if the stream is initialized, False otherwise
        """
        return self._initialized

    @staticmethod
    def is_read_stream(obj) -> bool:
        """Return True if obj is a stream-like object this SDK can use.
        Note: only method presence to identify streams are checked,
        not that they work (a broken stream can fail later).
        """
        if obj is None or isinstance(obj, (str, Path)):
            return False
        return all(hasattr(obj, method) for method in Stream._REQUIRED_STREAM_METHODS)


def _get_mime_type_from_path(path: Union[str, Path]) -> str:
    """Attempt to guess the MIME type from a file path's extension.
    When the extension is missing or unrecognized, this returns an empty
    string so the caller hands it to the lib for auto-detection.
    A recognized-but-wrong extension still returns a mimetype:
    the native layer will attempt to correct it from the bytes when
    reading (the real type still needs to be supported by the lib),
    and if it can't, an error will happen then.

    Args:
        path: File path as string or Path object

    Returns:
        MIME type string, or an empty string
          (when it cannot be determined from the extension).
        An empty string here means the native lib should attempt auto-detect.
    """
    path_obj = Path(path)
    file_extension = path_obj.suffix.lower() if path_obj.suffix else ""

    if file_extension == ".dng":
        # mimetypes guesses the wrong type for dng,
        # so we bypass it and set the correct type
        return "image/dng"
    else:
        # Fall back to an empty string for extensionless or unknown files.
        # Empty string flags this as a guess-type attempt.
        return mimetypes.guess_type(str(path))[0] or ""


def _get_supported_mime_types(ffi_func, cache):
    """Shared helper to retrieve supported MIME types from the native library.

    Args:
        ffi_func: The FFI function to call (e.g. _lib.c2pa_reader_supported_mime_types)
        cache: The current cache value (frozenset or None)

    Returns:
        A tuple of (list of MIME type strings, updated cache value)
    """
    if cache is not None:
        return list(cache), cache

    count = ctypes.c_size_t()
    arr = ffi_func(ctypes.byref(count))

    if not arr:
        error = _read_native_error()
        raise C2paError(
            "Failed to get supported MIME types: "
            f"{error or 'Unknown error'}")

    if count.value <= 0:
        try:
            _lib.c2pa_free_string_array(arr, count.value)
        except Exception:
            pass
        return [], cache

    try:
        result = []
        for i in range(count.value):
            try:
                if arr[i] is None:
                    continue
                mime_type = arr[i].decode(
                    "utf-8", errors='replace').strip().lower()
                if mime_type:
                    result.append(mime_type)
            except Exception:
                continue
    finally:
        try:
            _lib.c2pa_free_string_array(arr, count.value)
        except Exception:
            pass

    if result:
        cache = frozenset(result)

    if cache:
        return list(cache), cache
    return [], cache


def _encode_format(
    format_str: Optional[str],
    class_name: str,
    allow_autodetect: bool = True,
) -> Optional[bytes]:
    """Normalize a MIME type/format string and encode it to UTF-8 bytes.

    The binding does not validate the format itself: the native library is the
    authority on what is supported and detects the asset type from the bytes,
    so the format is passed straight through after trimming whitespace.

    None, an empty string, or whitespace all mean the same thing: no format was
    given. When allow_autodetect is True (default), that requests detection and
    the native library guesses the type from the bytes. When allow_autodetect
    is False, a missing format is rejected instead.

    Args:
        format_str: The MIME type or format, or None. Pass None, an empty
            string, or whitespace to request detection from the asset's bytes
            (only when ``allow_autodetect`` is True).
        class_name: Name of the calling class (for error messages).
        allow_autodetect: When True (default), a missing format requests
            detection. When False, a missing format raises
            C2paError.NotSupported.

    Returns:
        The lowercased UTF-8 format bytes, or None to request auto-detection
        (no format given). Use _format_ffi_arg to turn the result into the
        empty-bytes flag the native library expects.

    Raises:
        C2paError.NotSupported: If the format is missing and
            ``allow_autodetect`` is False.
        C2paError.Encoding: If the format contains invalid UTF-8 characters.
    """
    key = (format_str or "").strip().lower()
    if not key:
        if allow_autodetect:
            return None
        raise C2paError.NotSupported(
            f"{class_name} requires an explicit format (MIME type)"
        )
    try:
        return key.encode('utf-8')
    except UnicodeError as e:
        raise C2paError.Encoding(
            f"Invalid UTF-8 characters in input: {e}")


def _format_ffi_arg(fmt: Optional[bytes]) -> bytes:
    """Convert an encoded format to the native FFI argument.

    The native library treats empty bytes as the "detect the type from the
    bytes" flag, so a missing format (None) maps to b"" rather than a NULL
    ``c_char_p``.
    """
    return fmt if fmt is not None else b""


class Reader(ManagedResource):
    """High-level wrapper for C2PA Reader operations.

    Example:
        ```
        with Reader("image/jpeg", output) as reader:
            manifest_json = reader.json()
        ```
        Where `output` is either an in-memory stream or an opened file.
    """

    # Supported mimetypes cache
    _supported_mime_types_cache = None

    # Class-level error messages to avoid multiple creation
    _ERROR_MESSAGES = {
        'io_error': "IO error: {}",
        'manifest_error': "Invalid manifest data: must be bytes",
        'reader_error': "Failed to create reader: {}",
        'cleanup_error': "Error during cleanup: {}",
        'stream_error': "Error cleaning up stream: {}",
        'encoding_error': "Invalid UTF-8 characters in input: {}",
        'fragment_error': "Failed to process fragment: {}"
    }

    @classmethod
    def get_supported_mime_types(cls) -> list[str]:
        """Get the list of supported MIME types for the Reader.
        This method retrieves supported MIME types from the native library.

        Returns:
            List of supported MIME type strings

        Raises:
            C2paError: If there was an error retrieving the MIME types
        """
        result, cls._supported_mime_types_cache = _get_supported_mime_types(
            _lib.c2pa_reader_supported_mime_types, cls._supported_mime_types_cache)
        return result

    @classmethod
    def _is_mime_type_supported(cls, mime_type: str) -> bool:
        """Check if a MIME type is supported.

        Not used internally: the native library is the authority on format
        support and detects the type from the bytes. Kept for callers that
        want a pre-flight check before handing an asset to a Reader.

        Args:
            mime_type: The MIME type to check

        Returns:
            True if the MIME type is supported
        """
        if cls._supported_mime_types_cache is None:
            cls.get_supported_mime_types()
        return mime_type in cls._supported_mime_types_cache

    @classmethod
    @overload
    def try_create(
        cls,
        stream: Any,
        manifest_data: Optional[Any] = None,
        context: Optional['ContextProvider'] = None,
    ) -> Optional["Reader"]: ...

    @classmethod
    @overload
    def try_create(
        cls,
        format_or_path: Union[str, Path, None] = None,
        stream: Optional[Any] = None,
        manifest_data: Optional[Any] = None,
    ) -> Optional["Reader"]: ...

    @classmethod
    @overload
    def try_create(
        cls,
        format_or_path: Union[str, Path, None],
        stream: Optional[Any],
        manifest_data: Optional[Any],
        context: 'ContextProvider',
    ) -> Optional["Reader"]: ...

    @classmethod
    def try_create(
        cls,
        format_or_path: Union[str, Path, None] = None,
        stream: Optional[Any] = None,
        manifest_data: Optional[Any] = None,
        context: Optional['ContextProvider'] = None,
    ) -> Optional["Reader"]:
        """This is a factory method to create a new Reader,
        returning None if no manifest/c2pa data/JUMBF data could be read
        (instead of raising a ManifestNotFound: no JUMBF data found exception).

        Returns None instead of raising C2paError.ManifestNotFound if no
        C2PA manifest data is found in the asset. This is useful when you
        want to check if an asset contains C2PA data without handling
        exceptions for the expected case of no manifest.

        Pass a stream as the only argument (``try_create(stream)``) to read it
        with an auto-detected format.

        Args:
            format_or_path: The format or path to read from, or a stream to
                read with an auto-detected format. None or an empty string
                requests auto-detection (best effort).
            stream: Optional stream to read from (Python stream-like object)
            manifest_data: Optional manifest data in bytes
            context: Optional ContextProvider for settings

        Returns:
            Reader instance if the asset contains C2PA data,
            None if no manifest found (ManifestNotFound: no JUMBF data found)

        Raises:
            C2paError: If there was an error other than ManifestNotFound
        """
        try:
            return cls(
                format_or_path, stream, manifest_data,
                context=context,
            )
        except C2paError.ManifestNotFound:
            return None

    @overload
    def __init__(
        self,
        stream: Any,
        manifest_data: Optional[Any] = None,
        context: Optional['ContextProvider'] = None,
    ) -> None: ...

    @overload
    def __init__(
        self,
        format_or_path: Union[str, Path, None] = None,
        stream: Optional[Any] = None,
        manifest_data: Optional[Any] = None,
    ) -> None: ...

    @overload
    def __init__(
        self,
        format_or_path: Union[str, Path, None],
        stream: Optional[Any],
        manifest_data: Optional[Any],
        context: 'ContextProvider',
    ) -> None: ...

    def __init__(
        self,
        format_or_path: Union[str, Path, None] = None,
        stream: Optional[Any] = None,
        manifest_data: Optional[Any] = None,
        context: Optional['ContextProvider'] = None,
    ):
        """Create a new Reader.

        The format is optional. Passing a known format gives the native
        library more to work with, so prefer it. Pass None, an empty string,
        or an extensionless file path to let the library detect the type from
        the asset bytes.

        The library reconciles the format against the container it detects in
        the bytes: when the given format disagrees with the detected container,
        the library ignores the format and uses its own best guess (so reading
        does not fail on a wrong file extension); when no container is
        detected, the format is used as a hint and the asset is treated as a
        sidecar. If the bytes are not a recognized asset and no format resolves
        the type, a C2paError is raised.

        Pass a stream as the only argument (``Reader(stream)``) to read it with
        an auto-detected format.

        Args:
            format_or_path: The format (MIME type) or path to read from, or a
                stream to read with an auto-detected format. None or an empty
                string requests detection from the bytes.
            stream: Optional stream to read from (Python stream-like object)
            manifest_data: Optional manifest data in bytes
            context: Optional context implementing ContextProvider with settings

        Raises:
            C2paError: If there was an error creating the reader, including
              when the format cannot be detected from an unrecognized asset
            C2paError.Encoding: If any of the string inputs
              contain invalid UTF-8 characters
        """
        super().__init__()
        self._init_attrs()

        self._context = context

        # Only stream, no format: Reader(fh) must auto-detect on the stream.
        if stream is None and Stream.is_read_stream(format_or_path):
            stream = format_or_path
            format_or_path = None
        # A context supplies settings, not the asset, so a path or stream is
        # still required to read from.
        if format_or_path is None and stream is None:
            raise C2paError("Reader requires a path or a stream")

        if context is not None:
            self._init_from_context(
                context, format_or_path, stream,
                manifest_data,
            )
            return

        format_bytes = self._resolve_format_bytes(format_or_path, stream)

        if stream is None:
            # Create a stream from the file path in format_or_path.
            # A None format lets the native lib guess from the bytes.
            self._init_from_file(str(format_or_path), format_bytes)

        elif isinstance(stream, str):
            # stream is a file path, format_or_path is the format
            self._init_from_file(
                stream, format_bytes, manifest_data)

        else:
            # format_or_path is a format string, stream is a stream object
            self._init_from_stream(stream, format_bytes, manifest_data)

    @staticmethod
    def _resolve_format_bytes(format_or_path, stream) -> Optional[bytes]:
        """Resolve the encoded format for a (format_or_path, stream) pair.

        When only a path is given (``stream is None``), the format is derived
        from the file extension. Otherwise ``format_or_path`` is the format
        string (or None).
        Returns None to request auto-detection.
        """
        if stream is None:
            return _encode_format(
                _get_mime_type_from_path(str(format_or_path)), "Reader")
        return _encode_format(
            None if format_or_path is None else str(format_or_path), "Reader")

    def _create_reader(self, format_bytes, stream_obj,
                       manifest_data=None):
        """Create a native reader from a Stream
        and activate this Reader around it.

        Args:
            format_bytes: Encoded format/MIME type, or None for auto-detection
            stream_obj: A Stream instance
            manifest_data: Optional manifest bytes
        """
        format_arg = _format_ffi_arg(format_bytes)
        if manifest_data is None:
            def create():
                return _lib.c2pa_reader_from_stream(
                    format_arg, stream_obj._stream)
        else:
            if not isinstance(manifest_data, bytes):
                raise TypeError(Reader._ERROR_MESSAGES['manifest_error'])
            manifest_array = (
                ctypes.c_ubyte *
                len(manifest_data)).from_buffer_copy(manifest_data)

            def create():
                return _lib.c2pa_reader_from_manifest_data_and_stream(
                    format_arg,
                    stream_obj._stream,
                    manifest_array,
                    len(manifest_data),
                )

        self._create_and_activate(
            create, Reader._ERROR_MESSAGES['reader_error'])

    def _init_from_file(self, path, format_bytes,
                        manifest_data=None):
        """Open a file and create a reader from it.

        Args:
            path: File path to open
            format_bytes: UTF-8 encoded format/MIME type
            manifest_data: Optional manifest bytes
        """
        try:
            self._backing_file = open(path, 'rb')
            self._own_stream = Stream(self._backing_file)
            self._create_reader(format_bytes, self._own_stream, manifest_data)
        except C2paError:
            self._close_streams()
            raise
        except Exception as e:
            self._close_streams()
            raise C2paError.Io(
                Reader._ERROR_MESSAGES['io_error'].format(str(e)))

    def _init_from_stream(self, stream, format_bytes,
                          manifest_data=None):
        """Create a reader from a caller-supplied stream object.
        The native reader reads through this stream as long as it's alive,
        so the wrapper is stored on the instance and released by _release().

        Args:
            stream: A stream-like object owned by the caller
            format_bytes: UTF-8 encoded format/MIME type
            manifest_data: Optional manifest bytes
        """
        try:
            self._own_stream = Stream(stream)
            self._create_reader(format_bytes, self._own_stream, manifest_data)
        except Exception:
            self._close_streams()
            raise

    def _init_from_context(self, context, format_or_path,
                           stream, manifest_data=None):
        """Initialize Reader from a Context object implementing
        the ContextProvider interface/abstract base class.
        """
        if not context.is_valid:
            raise C2paError("Context is not valid")

        if manifest_data is not None and not isinstance(manifest_data, bytes):
            raise TypeError(Reader._ERROR_MESSAGES['manifest_error'])

        # Determine format and open stream
        format_bytes = self._resolve_format_bytes(format_or_path, stream)
        format_arg = _format_ffi_arg(format_bytes)
        if stream is None:
            # A None format lets the native lib guess from the bytes.
            self._backing_file = open(str(format_or_path), 'rb')
            self._own_stream = Stream(self._backing_file)
        elif isinstance(stream, str):
            self._backing_file = open(stream, 'rb')
            self._own_stream = Stream(self._backing_file)
        else:
            self._own_stream = Stream(stream)

        try:
            # The Context is caller-supplied and may be shared, so its handle
            # needs its own in-flight guard across the native call.
            with _context_guard(context):
                # Adopt before the consuming call: _consume_and_swap needs an
                # active resource, and cleanup then owns the pointer either
                # way.
                self._create_and_activate(
                    lambda: _lib.c2pa_reader_from_context(
                        context.execution_context),
                    Reader._ERROR_MESSAGES['reader_error'])

            _check_cstr_arg('format', format_arg)
            _check_handle_arg('stream', self._own_stream._stream)
            if manifest_data is not None:
                _check_bytes_arg('manifest_data', manifest_data)
                manifest_array = (
                    ctypes.c_ubyte *
                    len(manifest_data)).from_buffer_copy(manifest_data)
                # Consume current reader,
                # with manifest data and stream (C FFI pattern),
                # to switch it out using _consume_and_swap.
                self._consume_and_swap(
                    lambda handle: (
                        _lib.c2pa_reader_with_manifest_data_and_stream(
                            handle,
                            format_arg,
                            self._own_stream._stream,
                            manifest_array,
                            len(manifest_data),
                        )
                    ),
                    Reader._ERROR_MESSAGES['reader_error'])
            else:
                # Consume reader with stream
                self._consume_and_swap(
                    lambda handle: _lib.c2pa_reader_with_stream(
                        handle, format_arg,
                        self._own_stream._stream,
                    ),
                    Reader._ERROR_MESSAGES['reader_error'])
        except Exception:
            self._close_streams()
            raise

    def _init_attrs(self):
        super()._init_attrs()
        self._own_stream = None

        # Tracks a file we opened ourselves and must close later.
        self._backing_file = None

        # Fragment streams handed to the native reader by with_fragment,
        # which it keeps reading from for the rest of its lifecycle.
        self._fragment_streams = []

        # Serializes with_fragment against itself.
        self._fragment_lock = threading.RLock()

        # Caches for manifest JSON string and parsed data.
        # These are invalidated when with_fragment() is called.
        self._manifest_json_str_cache = None
        self._manifest_data_cache = None

        self._context = None

    def _close_streams(self):
        """Close owned stream and backing file if present."""
        if self._own_stream:
            try:
                self._own_stream.close()
            except Exception:
                logger.error("Failed to close Reader stream")
            finally:
                self._own_stream = None
        if self._backing_file:
            try:
                self._backing_file.close()
            except Exception:
                logger.warning("Failed to close Reader backing file")
            finally:
                self._backing_file = None
        for fragment in getattr(self, '_fragment_streams', []):
            try:
                fragment.close()
            except Exception:
                logger.warning("Failed to close Reader fragment stream")
        self._fragment_streams = []

    def _release(self):
        """Release Reader-specific resources (caches, stream, backing file).
        """

        self._manifest_json_str_cache = None
        self._manifest_data_cache = None
        self._close_streams()
        # The Context is not ours to close, only to stop pinning.
        self._context = None

    def _get_cached_manifest_data(self) -> Optional[dict]:
        """Get the cached manifest data, fetching and parsing if not cached.

        Returns:
            A dictionary containing the parsed manifest data, or None if
            JSON parsing fails

        Raises:
            C2paError: If there was an error getting the JSON
        """
        # Locked so the cache fields can't be read and written
        # across concurrent handle swaps.
        with self._guarded_op():
            self._ensure_valid_state()
            if self._manifest_data_cache is None:
                if self._manifest_json_str_cache is None:
                    self._manifest_json_str_cache = self.json()

                try:
                    self._manifest_data_cache = json.loads(
                        self._manifest_json_str_cache
                    )
                except json.JSONDecodeError:
                    # Next call should retry the read.
                    self._manifest_data_cache = None
                    self._manifest_json_str_cache = None
                    return None

            return self._manifest_data_cache

    def with_fragment(self, format: Optional[str], stream,
                      fragment_stream) -> "Reader":
        """Process a BMFF fragment stream with this reader.

        Used for fragmented BMFF media (DASH/HLS streaming) where
        content is split into init segments and fragment files.

        Args:
            format: MIME type of the media (e.g., "video/mp4"). None or an
                empty string requests detection from the bytes; the native
                library reconciles the format against the detected container.
            stream: Stream-like object with the main/init segment data
            fragment_stream: Stream-like object with the fragment data

        Returns:
            This reader instance, for method chaining.

        Raises:
            C2paError: If there was an error processing the fragment.
                On failure the native call may already have consumed the
                underlying object, in which case this Reader is closed and
                cannot be retried: create a new one.
            C2paError: "Reader is already processing a fragment on another
                thread" when another thread is inside this method on the same
                Reader. The Reader is untouched, and the call can be retried
                after the other one returns. One thread feeds fragments to a
                Reader, and the caller serializes those calls.
            C2paError: "Reader is in use by another operation" when another
                native call is in flight on it.

        While this call runs, read methods on other threads raise
        C2paError("Reader is running a mutating operation") and is_valid is
        False. The Reader is usable again when the call returns successfully.
        A thread that calls read methods in a loop without yielding keeps
        this call refused; yield between reads.
        """
        format_arg = _format_ffi_arg(_encode_format(format, "Reader"))

        # A forked child cannot wait on a lock no surviving thread will
        # release, so it reports the same error _live_op_lock() does.
        if is_foreign_process(self):
            raise C2paError(f"{type(self).__name__} is closed")

        # The native call and the ownership transfer are one unit.
        # Reentrant so a thread already here can continue.
        if not self._fragment_lock.acquire(blocking=False):
            raise C2paError(
                f"{type(self).__name__} is already processing a fragment "
                f"on another thread")
        try:
            # The native reader keeps reading through both streams.
            main_obj = Stream(stream)
            frag_obj = None
            try:
                frag_obj = Stream(fragment_stream)
                _check_cstr_arg('format', format_arg)
                _check_handle_arg('stream', main_obj._stream)
                _check_handle_arg('fragment', frag_obj._stream)

                def with_fragment_call(handle):
                    # Cleared here because these describe the replaced handle,
                    # and a reader must never be served them.
                    self._manifest_json_str_cache = None
                    self._manifest_data_cache = None
                    return _lib.c2pa_reader_with_fragment(
                        handle,
                        format_arg,
                        main_obj._stream,
                        frag_obj._stream,
                    )

                self._consume_and_swap(
                    with_fragment_call,
                    Reader._ERROR_MESSAGES['fragment_error'])
            except Exception:
                main_obj.close()
                if frag_obj is not None:
                    frag_obj.close()
                raise

            with self._guarded_op(refuse_mut=False):
                try:
                    self._ensure_valid_state()
                except Exception:
                    main_obj.close()
                    frag_obj.close()
                    raise

                # Replace the streams this reader owned, closing the previous
                # ones (only the current fragment is retained).
                previous = self._own_stream
                previous_fragments = self._fragment_streams
                self._own_stream = main_obj
                self._fragment_streams = [frag_obj]
                if previous is not None and previous is not main_obj:
                    try:
                        previous.close()
                    except Exception:
                        logger.warning(
                            "Failed to close previous Reader stream")
                for fragment in previous_fragments:
                    if fragment is frag_obj:
                        continue
                    try:
                        fragment.close()
                    except Exception:
                        logger.warning(
                            "Failed to close Reader fragment stream")
        finally:
            self._fragment_lock.release()

        return self

    def json(self) -> str:
        """Get the manifest store as a JSON string.

        Returns:
            The manifest store as a JSON string

        Raises:
            C2paError: If there was an error getting the JSON
        """

        with self._native_call():
            if self._manifest_json_str_cache is not None:
                return self._manifest_json_str_cache

            result = _lib.c2pa_reader_json(self._handle)
            _check_ffi_operation_result(
                result, "Error during manifest parsing in Reader")

            self._manifest_json_str_cache = _convert_to_py_string(result)
            return self._manifest_json_str_cache

    def detailed_json(self) -> str:
        """Get the detailed JSON representation of the C2PA manifest store.

        This method returns a more detailed JSON string than Reader.json(),
        providing additional information about the manifest structure.
        Note that the returned JSON by this method has a slightly different
        structure than the one returned by Reader.json().

        Returns:
            A JSON string containing the detailed manifest store data.

        Raises:
            C2paError: If there is an error reading the manifest data or if
                      the Reader has been closed.
        """

        with self._native_call():
            result = _lib.c2pa_reader_detailed_json(self._handle)
            _check_ffi_operation_result(
                result, "Error during detailed manifest parsing in Reader")

            return _convert_to_py_string(result)

    def crjson(self) -> str:
        """Get the manifest store as a crJSON string.

        crJSON is a standardized JSON format for C2PA manifest data. This
        call yields empty JSON ("{}") when there are no Content Credentials.

        Returns:
            The manifest store as a crJSON string.

        Raises:
            C2paError: If the Reader has been closed or the underlying C
                      call returns null.
        """

        with self._native_call():
            result = _lib.c2pa_reader_crjson(self._handle)
            _check_ffi_operation_result(result, "Error parsing crJSON")

            return _convert_to_py_string(result)

    def _get_manifest_field(self, extractor):
        """Extract a field from (cached) manifest data, or None if unavailable.

        Args:
            extractor: A callable that takes the parsed manifest dict
                and returns the desired field value.

        Returns:
            Extracted field value, or None if not available.
        """
        try:
            data = self._get_cached_manifest_data()
            if data is None:
                return None
            return extractor(data)
        except C2paError.ManifestNotFound:
            return None

    def get_active_manifest(self) -> Optional[dict]:
        """Get the active manifest from the manifest store.

        This method retrieves the full manifest JSON and extracts the active
        manifest based on the active_manifest key.

        Returns:
            A dictionary containing the active manifest data, including claims,
            assertions, ingredients, and signature information, or None if no
            manifest is found or if there was an error parsing the JSON.

        Raises:
            KeyError: If the active_manifest key is missing from the JSON
        """
        def _extract(data):
            if "active_manifest" not in data:
                raise KeyError("No 'active_manifest' key found")
            active_manifest_id = data["active_manifest"]
            if "manifests" not in data:
                raise KeyError("No 'manifests' key found in manifest data")
            manifests = data["manifests"]
            if active_manifest_id not in manifests:
                raise KeyError("Active manifest not found in manifest store")
            return manifests[active_manifest_id]

        return self._get_manifest_field(_extract)

    def get_manifest(self, label: str) -> Optional[dict]:
        """Get a specific manifest from the manifest store by its label.

        This method retrieves the manifest JSON and extracts the manifest
        that corresponds to the provided manifest label/ID.

        Args:
            label: The manifest label/ID to look up in the manifest store

        Returns:
            A dictionary containing the manifest data for the specified label,
            or None if no manifest is found or if there was an error parsing
            the JSON.

        Raises:
            KeyError: If the manifests key is missing from the JSON
        """
        def _extract(data):
            if "manifests" not in data:
                raise KeyError("No 'manifests' key found in manifest data")
            manifests = data["manifests"]
            if label not in manifests:
                raise KeyError(f"Manifest {label} not found in manifest store")
            return manifests[label]

        return self._get_manifest_field(_extract)

    def get_validation_state(self) -> Optional[str]:
        """Get the validation state of the manifest store.

        This method retrieves the full manifest JSON and extracts the
        validation_state field, which indicates the overall validation
        status of the C2PA manifest.

        Returns:
            The validation state as a string,
            or None if the validation_state field is not present or if no
            manifest is found or if there was an error parsing the JSON.
        """
        return self._get_manifest_field(lambda d: d.get("validation_state"))

    def get_validation_results(self) -> Optional[dict]:
        """Get the validation results of the manifest store.

        This method retrieves the full manifest JSON and extracts
        the validation_results object, which contains detailed
        validation information.

        Returns:
            The validation results as a dictionary containing
            validation details, or None if the validation_results
            field is not present or if no manifest is found or if
            there was an error parsing the JSON.
        """
        return self._get_manifest_field(lambda d: d.get("validation_results"))

    def resource_to_stream(self, uri: str, stream: Any) -> int:
        """Write a resource to a stream (shared borrow).

        Args:
            uri: The URI of the resource to write
            stream: The stream to write to (any Python stream-like object)

        Returns:
            The number of bytes written

        Raises:
            C2paError: If there was an error writing the resource to stream
        """
        _check_cstr_arg("uri", uri)
        uri_str = uri.encode('utf-8')
        with self._native_call(), Stream(stream) as stream_obj:
            result = _lib.c2pa_reader_resource_to_stream(
                self._handle, uri_str, stream_obj._stream)

            _check_ffi_operation_result(
                result,
                "Error during resource {} to stream conversion".format(uri),
                check=lambda r: r < 0)

            return result

    def is_embedded(self) -> bool:
        """Check if the reader was created from an embedded manifest.
        This method determines whether the C2PA manifest is embedded directly
        in the asset file or stored remotely.
        Returns:
            True if the reader was created from an embedded manifest,
            False if it was created from a remote manifest
        Raises:
            C2paError: If there was an error checking the embedded status
        """
        with self._native_call():
            result = _lib.c2pa_reader_is_embedded(self._handle)

            return bool(result)

    def get_remote_url(self) -> Optional[str]:
        """Get the remote URL of the manifest if it was obtained remotely.
        This method returns the URL from which the C2PA manifest was fetched
        if the reader was created from a remote manifest. If the manifest
        is embedded in the asset, this will return None.
        Returns:
            The remote URL as a string if the manifest was obtained remotely,
            None if the manifest is embedded or no remote URL is available
        Raises:
            C2paError: If there was an error getting the remote URL
        """
        with self._native_call():
            result = _lib.c2pa_reader_remote_url(self._handle)

            if result is None:
                # No remote URL set (manifest is embedded).
                return None

            return _convert_to_py_string(result)


class Signer(ManagedResource):
    """High-level wrapper for C2PA Signer operations."""

    # Class-level error messages to avoid multiple creation
    _ERROR_MESSAGES = {
        'cleanup_error': "Error during cleanup: {}",
        'callback_error': "Error in signer callback: {}",
        'invalid_certs': "Invalid certificate data: {}",
        'invalid_tsa': "Invalid TSA URL: {}",
        'encoding_error': "Invalid UTF-8 characters in input: {}"
    }

    @classmethod
    def from_info(cls, signer_info: C2paSignerInfo) -> 'Signer':
        """Create a new Signer from signer information.

        Args:
            signer_info: The signer configuration

        Returns:
            A new Signer instance

        Raises:
            C2paError: If there was an error creating the signer
        """
        with _native_section():
            signer_ptr = _lib.c2pa_signer_from_info(ctypes.byref(signer_info))

            _check_ffi_operation_result(
                signer_ptr,
                "Failed to create signer from configured signer_info")

        try:
            return cls(signer_ptr)
        except Exception:
            # No instance took ownership, so the handle is still ours.
            ManagedResource._free_native_ptr(signer_ptr)
            raise

    @classmethod
    def from_callback(
        cls,
        callback: Callable[[bytes], bytes],
        alg: C2paSigningAlg,
        certs: str,
        tsa_url: Optional[str] = None
    ) -> 'Signer':
        """Create a signer from a callback function.

        Args:
            callback: Function that signs data and returns the signature
            alg: The signing algorithm to use
            certs: Certificate chain in PEM format
            tsa_url: Optional RFC 3161 timestamp authority URL

        Returns:
            A new Signer instance

        Raises:
            C2paError: If there was an error creating the signer
            C2paError.Encoding: If the certificate data or TSA URL
              contains invalid UTF-8 characters
        """
        # Validate inputs before creating
        if not certs:
            raise C2paError(
                cls._ERROR_MESSAGES['invalid_certs'].format(
                    "Missing certificate data"
                )
            )

        if tsa_url and not tsa_url.startswith(("http://", "https://")):
            raise C2paError(
                cls._ERROR_MESSAGES['invalid_tsa'].format(
                    "Invalid TSA URL format"
                )
            )

        # Create a wrapper callback that handles errors and memory management
        def wrapped_callback(
                context,
                data_ptr,
                data_len,
                signed_bytes_ptr,
                signed_len):
            # Returns -1 on error as it is what the native code expects.
            # The reason is that otherwise we ping-pong errors
            # between native code and Python code,
            # which can become tedious in handling.
            # So we let the native code deal with it and
            # raise the errors accordingly, since it already does checks.
            try:
                if (
                    not data_ptr
                    or data_len <= 0
                    or not signed_bytes_ptr
                    or signed_len <= 0
                ):
                    # Error: invalid input, invalid so return -1,
                    # native code will handle it!
                    return -1

                # Validate buffer sizes before memory operations
                if data_len > 1024 * 1024:  # 1MB limit
                    return -1

                data = ctypes.string_at(data_ptr, data_len)

                if not data:
                    # Error: empty data, invalid so return -1,
                    # native code will also handle it!
                    return -1

                # Call the user's callback
                signature = callback(data)
                if not signature:
                    # Error: empty signature, invalid so return -1,
                    # native code will handle that too!
                    return -1

                # Copy the signature back to the C buffer
                # (since callback is used in native code)
                actual_len = min(len(signature), signed_len)
                # Use memmove for efficient memory copying instead of
                # byte-by-byte loop
                ctypes.memmove(signed_bytes_ptr, signature, actual_len)

                # Native code expects the signed len to be returned, we oblige
                return actual_len
            except Exception as e:
                logger.error(
                    cls._ERROR_MESSAGES['callback_error'].format(
                        str(e)))
                # Error: exception raised, invalid so return -1,
                # native code will handle the error when seeing -1
                return -1

        # Encode strings with error handling in case it's invalid UTF8
        try:
            # Only encode if not already bytes, avoid unnecessary encoding
            certs_bytes = certs.encode(
                'utf-8') if isinstance(certs, str) else certs
            tsa_url_bytes = tsa_url.encode(
                'utf-8') if tsa_url and isinstance(tsa_url, str) else tsa_url
        except UnicodeError as e:
            raise C2paError.Encoding(
                cls._ERROR_MESSAGES['encoding_error'].format(
                    str(e)))

        # Create the callback object using the callback function
        callback_cb = SignerCallback(wrapped_callback)

        # Create the signer with the wrapped callback
        with _native_section():
            signer_ptr = _lib.c2pa_signer_create(
                None,
                callback_cb,
                alg,
                certs_bytes,
                tsa_url_bytes
            )

            _check_ffi_operation_result(signer_ptr,
                                        "Failed to create signer")

        try:
            # Create and return the signer instance with the callback
            signer_instance = cls(signer_ptr)

            # Keep callback alive on the object to prevent gc of the callback.
            # So the callback will live as long as the signer leaves,
            # and there is a 1:1 relationship between signer and callback.
            signer_instance._callback_cb = callback_cb
        except Exception:
            # No instance took ownership, so the handle is still ours.
            ManagedResource._free_native_ptr(signer_ptr)
            raise

        return signer_instance

    def __init__(self, signer_ptr: ctypes.POINTER(C2paSigner)):
        """Initialize a new Signer instance. This constructor is not meant
        to be called directly. Use from_info() or from_callback() instead.

        Args:
            signer_ptr: Pointer to the native C2PA signer

        Raises:
            C2paError: If the signer pointer is invalid
        """
        super().__init__()
        self._init_attrs()

        if not signer_ptr:
            raise C2paError("Invalid signer pointer: pointer is null")

        self._activate(signer_ptr)

    def _init_attrs(self):
        super()._init_attrs()
        # from_callback() replaces this with the real callback, which has to
        # outlive the signer that calls it.
        self._callback_cb = None

    def _release(self):
        """Release Signer-specific resources (callback reference)."""
        if self._callback_cb:
            self._callback_cb = None

    def reserve_size(self) -> int:
        """Get the size to reserve for signatures from this signer.

        Returns:
            The size to reserve in bytes

        Raises:
            C2paError: If there was an error getting the size
        """
        with self._guarded_op():
            self._ensure_valid_state()

            result = _lib.c2pa_signer_reserve_size(self._handle)

            _check_ffi_operation_result(
                result,
                "Failed to get reserve size",
                check=lambda r: r < 0)

            return result


class Builder(ManagedResource):
    """High-level wrapper for C2PA Builder operations."""

    # Supported mimetypes cache
    _supported_mime_types_cache = None

    # Class-level error messages to avoid multiple creation
    _ERROR_MESSAGES = {
        'builder_error': "Failed to create builder: {}",
        'cleanup_error': "Error during cleanup: {}",
        'url_error': "Error setting remote URL: {}",
        'intent_error': "Error setting intent for Builder: {}",
        'resource_error': "Error adding resource: {}",
        'ingredient_error': "Error adding ingredient: {}",
        'archive_read_error': "Error loading ingredient from archive: {}",
        'action_error': "Error adding action: {}",
        'archive_error': "Error writing archive: {}",
        'archive_load_error': "Failed to load archive into builder: {}",
    }

    @classmethod
    def get_supported_mime_types(cls) -> list[str]:
        """Get the list of supported MIME types for the Builder.
        This method retrieves supported MIME types from the native library.

        Returns:
            List of supported MIME type strings

        Raises:
            C2paError: If there was an error retrieving the MIME types
        """
        result, cls._supported_mime_types_cache = _get_supported_mime_types(
            _lib.c2pa_builder_supported_mime_types, cls._supported_mime_types_cache)
        return result

    @classmethod
    @overload
    def from_json(
        cls,
        manifest_json: Any,
    ) -> 'Builder': ...

    @classmethod
    @overload
    def from_json(
        cls,
        manifest_json: Any,
        context: 'ContextProvider',
    ) -> 'Builder': ...

    @classmethod
    def from_json(
        cls,
        manifest_json: Any,
        context: Optional['ContextProvider'] = None,
    ) -> 'Builder':
        """Create a new Builder from a JSON manifest.

        Args:
            manifest_json: The JSON manifest definition
            context: Optional ContextProvider for settings

        Returns:
            A new Builder instance

        Raises:
            C2paError: If there was an error creating the builder
        """
        return cls(manifest_json, context=context)

    @classmethod
    def from_archive(
        cls,
        stream: Any,
    ) -> 'Builder':
        """Create a new Builder from an archive stream.

        This creates builder without a context. To use a context,
        create a Builder with a context first, then call with_archive() on it.

        Args:
            stream: The stream containing the archive
                (any Python stream-like object)

        Returns:
            A new Builder instance (without any context)

        Raises:
            C2paError: If there was an error creating the builder
                from archive
        """
        stream_obj = Stream(stream)

        try:
            with _native_section():
                handle = _lib.c2pa_builder_from_archive(stream_obj._stream)

                _check_ffi_operation_result(
                    handle, "Failed to create builder from archive")

            try:
                # A builder from an archive here carries no context.
                return cls._wrap_native_handle(handle)
            except Exception:
                # No instance took ownership, so the handle is still ours.
                ManagedResource._free_native_ptr(handle)
                raise
        finally:
            stream_obj.close()

    @overload
    def __init__(
        self,
        manifest_json: Any,
    ) -> None: ...

    @overload
    def __init__(
        self,
        manifest_json: Any,
        context: 'ContextProvider',
    ) -> None: ...

    def __init__(
        self,
        manifest_json: Any,
        context: Optional['ContextProvider'] = None,
    ):
        """Initialize a new Builder instance.

        Args:
            manifest_json: The manifest JSON definition (string or dict)
            context: Optional Context (ContextProvider) for settings

        Raises:
            C2paError: If there was an error creating the builder
            C2paError.Encoding: If manifest JSON contains invalid UTF-8 chars
            C2paError.Json: If the manifest JSON cannot be serialized
        """
        super().__init__()
        self._init_attrs()

        self._context = context
        self._has_context_signer = (
            context is not None
            and hasattr(context, 'has_signer')
            and context.has_signer
        )

        json_str = _to_utf8_bytes(manifest_json, "manifest JSON")

        if context is not None:
            self._init_from_context(context, json_str)
        else:
            self._create_and_activate(
                lambda: _lib.c2pa_builder_from_json(json_str),
                Builder._ERROR_MESSAGES['builder_error'])

    def _init_from_context(self, context, json_str):
        """Initialize Builder from a ContextProvider.

        Uses c2pa_builder_from_context +
        c2pa_builder_with_definition (consume-and-return).
        """
        if not context.is_valid:
            raise C2paError("Context is not valid")

        # The Context is caller-supplied and may be shared,
        # so its handle needs its own in-flight guard across
        # the native call, especially for state checks.
        with _context_guard(context):
            # Adopt before the consuming call.
            self._create_and_activate(
                lambda: _lib.c2pa_builder_from_context(
                    context.execution_context),
                Builder._ERROR_MESSAGES['builder_error'])

        _check_cstr_arg('manifest_json', json_str)
        # _consume_and_swap reserves the handle.
        self._consume_and_swap(
            lambda handle: _lib.c2pa_builder_with_definition(
                handle, json_str),
            Builder._ERROR_MESSAGES['builder_error'])

    def _init_attrs(self):
        super()._init_attrs()
        self._context = None
        self._has_context_signer = False

    def _release(self):
        """Release the Builder's reference to its Context."""
        # The Context is not ours to close, only to stop pinning.
        self._context = None

    def set_no_embed(self):
        """Set the no-embed flag.

        When set, the builder will not embed a C2PA manifest store
        into the asset when signing.
        This is useful when creating cloud or sidecar manifests.
        """
        with self._guarded_op(exclusive=True):
            self._ensure_valid_state()
            _lib.c2pa_builder_set_no_embed(self._handle)

    def set_remote_url(self, remote_url: str):
        """Set the remote URL.

        When set, the builder embeds a remote URL into the asset when signing.
        This is useful when creating cloud based Manifests.

        Args:
            remote_url: The remote URL to set

        Raises:
            C2paError: If there was an error setting the remote URL
        """
        url_bytes = _to_utf8_bytes(remote_url, "remote URL")

        with self._guarded_op(exclusive=True):
            self._ensure_valid_state()

            result = _lib.c2pa_builder_set_remote_url(self._handle, url_bytes)

            _check_ffi_operation_result(
                result,
                Builder._ERROR_MESSAGES['url_error'],
                check=lambda r: r != 0)

    def set_intent(
        self,
        intent: C2paBuilderIntent,
        digital_source_type: C2paDigitalSourceType = (
            C2paDigitalSourceType.EMPTY
        )
    ):
        """Set the intent for the manifest.

        The intent specifies what kind of manifest to create:
        - CREATE: New with specified digital source type.
                  Must not have a parent ingredient.
        - EDIT: Edit of a pre-existing parent asset.
                Must have a parent ingredient.
        - UPDATE: Restricted version of Edit for non-editorial changes.
                  Must have only one ingredient, as a parent.

        Args:
            intent: The builder intent (C2paBuilderIntent enum value)
            digital_source_type: The digital source type (required
                for CREATE intent). Defaults to C2paDigitalSourceType.EMPTY
                (for all other cases).

        Raises:
            C2paError: If there was an error setting the intent
        """
        with self._guarded_op(exclusive=True):
            self._ensure_valid_state()

            result = _lib.c2pa_builder_set_intent(
                self._handle,
                ctypes.c_uint(intent),
                ctypes.c_uint(digital_source_type),
            )

            _check_ffi_operation_result(
                result,
                Builder._ERROR_MESSAGES['intent_error'],
                check=lambda r: r != 0)

    def add_resource(self, uri: str, stream: Any):
        """Add a resource to the builder.

        Args:
            uri: The URI to identify the resource
            stream: The stream containing the resource data
              (any Python stream-like object)

        Raises:
            C2paError: If there was an error adding the resource
        """
        uri_bytes = _to_utf8_bytes(uri, "resource URI")
        with self._exclusive_native_call(), Stream(stream) as stream_obj:
            result = _lib.c2pa_builder_add_resource(
                self._handle, uri_bytes, stream_obj._stream)

            _check_ffi_operation_result(
                result,
                Builder._ERROR_MESSAGES['resource_error'],
                check=lambda r: r != 0)

    def add_ingredient(
        self, ingredient_json: Union[str, dict], format: str, source: Any
    ):
        """Add an ingredient to the builder (facade method).
        The added ingredient's source should be a stream-like object
        (for instance, a file opened as stream).

        Args:
            ingredient_json: The JSON ingredient definition
                (either a JSON string or a dictionary)
            format: The MIME type or extension of the ingredient
            source: The stream containing the ingredient data
              (any Python stream-like object)

        Raises:
            C2paError: If there was an error adding the ingredient
            C2paError.Encoding: If the ingredient JSON contains
              invalid UTF-8 characters

        Example:
            ```
            with open(ingredient_file_path, 'rb') as a_file:
                builder.add_ingredient(ingredient_json, "image/jpeg", a_file)
            ```
        """
        return self.add_ingredient_from_stream(ingredient_json, format, source)

    def add_ingredient_from_stream(
            self,
            ingredient_json: Union[str, dict],
            format: str,
            source: Any):
        """Add an ingredient from a stream to the builder.
        Explicitly named API requiring a stream as input parameter.

        Args:
            ingredient_json: The JSON ingredient definition
                (either a JSON string or a dictionary)
            format: The MIME type or extension of the ingredient
            source: The stream containing the ingredient data
              (any Python stream-like object)

        Raises:
            C2paError: If there was an error adding the ingredient
            C2paError.Encoding: If the ingredient JSON or format
              contains invalid UTF-8 characters
        """
        self._ensure_valid_state()

        ingredient_str = _to_utf8_bytes(ingredient_json, "ingredient JSON")
        format_str = _to_utf8_bytes(format, "ingredient format")

        with self._exclusive_native_call(), Stream(source) as source_stream:
            result = (
                _lib.c2pa_builder_add_ingredient_from_stream(
                    self._handle,
                    ingredient_str,
                    format_str,
                    source_stream._stream
                )
            )

            _check_ffi_operation_result(
                result,
                Builder._ERROR_MESSAGES['ingredient_error'],
                check=lambda r: r != 0)

    def add_action(self, action_json: Union[str, dict]) -> None:
        """Add an action to the builder, that will be placed
        in the actions assertion array in the generated manifest.

        Args:
            action_json: The JSON action definition
                (either a JSON string or a dictionary)

        Raises:
            C2paError: If there was an error adding the action
            C2paError.Encoding: If the action JSON contains invalid UTF-8 chars
        """
        action_str = _to_utf8_bytes(action_json, "action JSON")

        with self._guarded_op(exclusive=True):
            self._ensure_valid_state()

            result = _lib.c2pa_builder_add_action(self._handle, action_str)

            _check_ffi_operation_result(
                result,
                Builder._ERROR_MESSAGES['action_error'],
                check=lambda r: r != 0)

    def to_archive(self, stream: Any) -> None:
        """Write an archive of the builder to a stream.

        Args:
            stream: The stream to write the archive to
              (any Python stream-like object)

        Raises:
            C2paError: If there was an error writing the archive
        """
        with self._exclusive_native_call(), Stream(stream) as stream_obj:
            result = _lib.c2pa_builder_to_archive(
                self._handle, stream_obj._stream)

            _check_ffi_operation_result(
                result,
                Builder._ERROR_MESSAGES["archive_error"],
                check=lambda r: r != 0)

    def write_ingredient_archive(self, ingredient_id: str, stream: Any) -> None:
        """Write a single-ingredient archive for the named ingredient.
        The archive is in C2PA format.

        Args:
            ingredient_id: Identifier of the ingredient within this builder;
                matched against the ingredient's label or instance_id
            stream: Writable, seekable stream to receive the archive

        Raises:
            C2paError: If there was an error writing the archive
        """
        self._ensure_valid_state()

        ingredient_id_str = _to_utf8_bytes(ingredient_id, "ingredient_id")

        with self._exclusive_native_call(), Stream(stream) as stream_obj:
            result = _lib.c2pa_builder_write_ingredient_archive(
                self._handle, ingredient_id_str, stream_obj._stream)

            _check_ffi_operation_result(
                result,
                Builder._ERROR_MESSAGES["archive_error"],
                check=lambda r: r != 0)

    def add_ingredient_from_archive(self, stream: Any) -> None:
        """Add an ingredient from a per-ingredient archive stream.
        The archive must be in C2PA format, as written by
        write_ingredient_archive.

        Args:
            stream: Readable, seekable stream containing the ingredient archive

        Raises:
            C2paError: If there was an error reading the archive
        """
        with self._exclusive_native_call(), Stream(stream) as stream_obj:
            result = _lib.c2pa_builder_add_ingredient_from_archive(
                self._handle, stream_obj._stream)

            _check_ffi_operation_result(
                result,
                Builder._ERROR_MESSAGES["archive_read_error"],
                check=lambda r: r != 0)

    def with_archive(self, stream: Any) -> 'Builder':
        """Load an archive into this Builder instance, replacing its
        manifest definition. The archive carries only the
        definition, not settings. Settings come from the context that
        was configured to be used with this Builder instance.

        Args:
            stream: The stream containing the archive

        Returns:
            This builder instance, for method chaining.

        Raises:
            C2paError: If there was an error loading the archive. On failure
                the native call may already have consumed the underlying
                object, in which case this Builder is closed and cannot be
                retried: create a new one.
            C2paError: If another native call is in flight on this Builder.
        """
        self._ensure_valid_state()

        with Stream(stream) as stream_obj:
            _check_handle_arg('stream', stream_obj._stream)
            self._consume_and_swap(
                lambda handle: _lib.c2pa_builder_with_archive(
                    handle, stream_obj._stream),
                Builder._ERROR_MESSAGES['archive_load_error'])

        return self

    def _sign_internal(
            self,
            format: str,
            source_stream: Stream,
            dest_stream: Stream,
            signer: Optional[Signer] = None) -> bytes:
        """Internal signing implementation.
        When `signer` is provided, calls `c2pa_builder_sign` (explicit
        signer).  When `signer` is `None`, calls
        `c2pa_builder_sign_context` (context-based signer).
        Sign can only be called once on a Builder, as Builder objects
        are single-sign use. The Builder is closed after signing.

        Args:
            format: The MIME type or extension of the content. Required for
                signing: a missing format raises C2paError.NotSupported.
            source_stream: The source stream
            dest_stream: The destination stream,
                opened in w+b (write+read binary) mode.
            signer: Signer to use. When None the context
                signer is used instead.

        Returns:
            Manifest bytes

        Raises:
            C2paError: If there was an error during signing
        """
        self._ensure_valid_state()

        if signer is not None:
            if not hasattr(signer, '_handle') or not signer._handle:
                raise C2paError("Invalid or closed signer")

        # allow_autodetect=False, so this never returns None (raises instead).
        format_arg = _format_ffi_arg(
            _encode_format(format, "Builder", allow_autodetect=False))
        manifest_bytes_ptr = ctypes.POINTER(ctypes.c_ubyte)()

        # The Context pins the consumed signer's callback, which
        # native invokes during this call
        with self._exclusive_native_call():
            with (signer._native_call() if signer is not None
                  else _context_guard(self._context)):
                try:
                    if signer is not None:
                        result = _lib.c2pa_builder_sign(
                            self._handle,
                            format_arg,
                            source_stream._stream,
                            dest_stream._stream,
                            signer._handle,
                            ctypes.byref(manifest_bytes_ptr)
                        )
                    else:
                        result = _lib.c2pa_builder_sign_context(
                            self._handle,
                            format_arg,
                            source_stream._stream,
                            dest_stream._stream,
                            ctypes.byref(manifest_bytes_ptr),
                        )
                except Exception as e:
                    self.close()
                    raise C2paError(f"Error during signing: {e}") from e

                try:
                    _check_ffi_operation_result(
                        result,
                        "Error during signing",
                        check=lambda r: r < 0)
                finally:
                    # Single use for a Builder, once signed, close.
                    self.close()

        # Capture the manifest bytes if available
        manifest_bytes = b""
        if manifest_bytes_ptr and result > 0:
            try:
                manifest_bytes = ctypes.string_at(manifest_bytes_ptr, result)
            except Exception:
                manifest_bytes = b""
            finally:
                # Always free the C-allocated memory,
                # even if we failed to copy manifest bytes
                try:
                    _lib.c2pa_manifest_bytes_free(manifest_bytes_ptr)
                except Exception:
                    logger.error(
                        "Failed to release native manifest bytes memory"
                    )

        return manifest_bytes

    def _sign_common(
        self,
        signer: Optional[Signer],
        format: str,
        source: Any,
        dest: Any = None,
    ) -> bytes:
        """Shared signing logic for sign().
        Sign can only be called once on a Builder, as Builder objects
        are single-sign use. The Builder is closed after signing.

        Args:
            signer: The signer to use, or None for context signer.
            format: The MIME type of the content.
            source: The source stream.
            dest: The destination stream (optional).

        Returns:
            Manifest bytes
        """
        source_stream = Stream(source)
        try:
            # Identity check, not truthiness: a caller-supplied destination
            # that is falsy while empty (any stream-like object defining
            # __bool__/__len__) would otherwise be silently swapped for the
            # internal buffer and never receive the signed asset.
            if dest is not None:
                dest_stream = Stream(dest)
            else:
                mem_buffer = io.BytesIO()
                dest_stream = Stream(mem_buffer)

            try:
                if signer is not None:
                    manifest_bytes = self._sign_internal(
                        format, source_stream, dest_stream,
                        signer=signer,
                    )
                elif self._has_context_signer:
                    manifest_bytes = self._sign_internal(
                        format, source_stream, dest_stream)
                else:
                    raise C2paError(
                        "No signer provided. Either pass a"
                        " signer parameter or create the"
                        " Builder with a Context that has"
                        " a signer."
                    )
            finally:
                dest_stream.close()
        finally:
            source_stream.close()

        return manifest_bytes

    @overload
    def sign(
        self,
        signer: Signer,
        format: str,
        source: Any,
        dest: Any = None,
    ) -> bytes: ...

    @overload
    def sign(
        self,
        format: str,
        source: Any,
        dest: Any = None,
    ) -> bytes: ...

    def sign(
        self,
        signer_or_format: Union[Signer, str],
        format_or_source: Any = None,
        source_or_dest: Any = None,
        dest: Any = None,
    ) -> bytes:
        """Sign the builder's content.

        Can be called with or without an explicit signer.
        If no signer is provided, the context's signer is
        used (builder must have been created with a Context
        that has a signer).
        Sign can only be called once on a Builder, as Builder objects
        are single-sign use. The Builder is closed after signing.

        Args:
            signer: The signer to use. If not provided, the
                context's signer is used.
            format: The MIME type of the content.
            source: The source stream.
            dest: The destination stream (optional). When
                omitted, the signed asset is buffered into
                an in-memory `BytesIO` sized to the full
                output. For assets larger than a few MB,
                pass a file or other writable stream to
                avoid buffering the whole signed payload
                in memory.

        Returns:
            Manifest bytes

        Raises:
            C2paError: If there was an error during signing
        """
        if isinstance(signer_or_format, Signer):
            return self._sign_common(
                signer_or_format,
                format_or_source,
                source_or_dest,
                dest,
            )
        elif isinstance(signer_or_format, str):
            return self._sign_common(
                None,
                signer_or_format,
                format_or_source,
                source_or_dest,
            )
        else:
            raise C2paError(
                "First argument must be a Signer or a format string (MIME type)."
            )

    @overload
    def sign_file(
        self,
        source_path: Union[str, Path],
        dest_path: Union[str, Path],
        signer: Signer,
    ) -> bytes: ...

    @overload
    def sign_file(
        self,
        source_path: Union[str, Path],
        dest_path: Union[str, Path],
    ) -> bytes: ...

    def sign_file(
        self,
        source_path: Union[str, Path],
        dest_path: Union[str, Path],
        signer: Optional[Signer] = None,
    ) -> bytes:
        """Sign a file and write signed data to output.

        Can be called with or without an explicit signer.
        If no signer is provided, the context's signer is
        used (builder must have been created with a Context
        that has a signer).

        Args:
            source_path: Path to the source file.
            dest_path: Path to write the signed file to.
            signer: The signer to use. If None, the
                context's signer is used.

        Returns:
            Manifest bytes

        Raises:
            C2paError.NotSupported: If the format cannot be determined from
                the source path (extensionless or unrecognized extension),
                since signing requires an explicit, resolvable format.
            C2paError: If there was an error during signing
        """
        mime_type = _get_mime_type_from_path(source_path)
        if not mime_type:
            raise C2paError.NotSupported(
                "Could not determine the format (MIME type) from "
                f"'{source_path}'. Sign a stream with an explicit format "
                "instead, or use a recognized file extension.")

        try:
            with (
                open(source_path, 'rb') as source_file,
                open(dest_path, 'w+b') as dest_file,
            ):
                if signer is not None:
                    return self.sign(signer, mime_type, source_file, dest_file)
                # else:
                return self.sign(mime_type, source_file, dest_file)
        except C2paError:
            # Preserve C2paError and its subtypes
            raise
        except Exception as e:
            raise C2paError(f"Error signing file: {str(e)}") from e


def format_embeddable(format: str, manifest_bytes: bytes) -> tuple[int, bytes]:
    """Convert a binary C2PA manifest into an embeddable version.

    Args:
        format: The MIME type or extension of the target format
        manifest_bytes: The raw manifest bytes

    Returns:
        A tuple of (size of result bytes, embeddable manifest bytes)

    Raises:
        C2paError: If there was an error converting the manifest
    """
    _check_cstr_arg("format", format)
    format_str = format.encode('utf-8')
    manifest_array = (ctypes.c_ubyte * len(manifest_bytes)).from_buffer_copy(
        manifest_bytes
    )
    result_bytes_ptr = ctypes.POINTER(ctypes.c_ubyte)()

    with _native_section():
        result = _lib.c2pa_format_embeddable(
            format_str,
            manifest_array,
            len(manifest_bytes),
            ctypes.byref(result_bytes_ptr)
        )

        _check_ffi_operation_result(
            result,
            "Failed to format embeddable manifest",
            check=lambda r: r < 0)

    size = result
    if not result_bytes_ptr:
        raise C2paError(
            "Failed to format embeddable manifest: no data returned")
    try:
        result_bytes = ctypes.string_at(result_bytes_ptr, size)
    except Exception as e:
        raise C2paError(
            f"Failed to convert embeddable manifest bytes: {e}"
        ) from e
    finally:
        _lib.c2pa_manifest_bytes_free(result_bytes_ptr)

    return size, result_bytes


def create_signer(
    callback: Callable[[bytes], bytes],
    alg: C2paSigningAlg,
    certs: str,
    tsa_url: Optional[str] = None
) -> Signer:
    """Create a signer from a callback function (deprecated).

    .. deprecated:: 0.11.0
        This function is deprecated and will be removed in a future version.
        Please use the Signer class method instead.
        Example:
            ```
            signer = Signer.from_callback(callback, alg, certs, tsa_url)
            ```

    Args:
        callback: Function that signs data and returns the signature
        alg: The signing algorithm to use
        certs: Certificate chain in PEM format
        tsa_url: Optional RFC 3161 timestamp authority URL

    Returns:
        A new Signer instance

    Raises:
        C2paError: If there was an error creating the signer
        C2paError.Encoding: If the certificate data or TSA URL
          contains invalid UTF-8 characters
    """
    warnings.warn(
        "The create_signer function is deprecated and will be removed in a "
        "future version. Please use Signer.from_callback() instead.",
        DeprecationWarning,
        stacklevel=2,
    )

    return Signer.from_callback(callback, alg, certs, tsa_url)


def create_signer_from_info(signer_info: C2paSignerInfo) -> Signer:
    """Create a signer from signer information (deprecated).

    .. deprecated:: 0.11.0
        This function is deprecated and will be removed in a future version.
        Please use the Signer class method instead.
        Example:
            ```
            signer = Signer.from_info(signer_info)
            ```

    Args:
        signer_info: The signer configuration

    Returns:
        A new Signer instance

    Raises:
        C2paError: If there was an error creating the signer
    """
    warnings.warn(
        "The create_signer_from_info function is deprecated and will be "
        "removed in a future version. Please use Signer.from_info() instead.",
        DeprecationWarning,
        stacklevel=2,
    )

    return Signer.from_info(signer_info)


def ed25519_sign(data: bytes, private_key: str) -> bytes:
    """Sign data using the Ed25519 algorithm.

    Args:
        data: The data to sign
        private_key: The private key in PEM format

    Returns:
        The signature bytes

    Raises:
        C2paError: If there was an error signing the data
        C2paError.Encoding: If the private key contains invalid UTF-8 chars
    """
    if not data:
        raise C2paError("Data to sign cannot be empty")

    if not private_key or not isinstance(private_key, str):
        raise C2paError("Private key must be a non-empty string")

    # Create secure memory buffer for data
    data_array = None
    key_bytes = None

    try:
        # Create data array with size validation
        data_size = len(data)
        data_array = (ctypes.c_ubyte * data_size)(*data)

        # Encode private key to bytes
        try:
            _check_cstr_arg("private_key", private_key)
            key_bytes = private_key.encode('utf-8')
        except UnicodeError as e:
            raise C2paError.Encoding(
                f"Invalid UTF-8 characters in private key: {str(e)}")

        # Perform the signing operation
        with _native_section():
            signature_ptr = _lib.c2pa_ed25519_sign(
                data_array,
                data_size,
                key_bytes
            )

            _check_ffi_operation_result(signature_ptr,
                                        "Failed to sign data with Ed25519")

        try:
            # Ed25519 signatures are always 64 bytes
            signature = bytes(signature_ptr[:64])
        finally:
            _lib.c2pa_signature_free(signature_ptr)

        return signature

    finally:
        if key_bytes:
            ctypes.memset(key_bytes, 0, len(key_bytes))
            del key_bytes


__all__ = [
    'C2paError',
    'C2paSeekMode',
    'C2paSigningAlg',
    'C2paDigitalSourceType',
    'C2paSignerInfo',
    'C2paBuilderIntent',
    'ContextBuilder',
    'ContextProvider',
    'Settings',
    'Context',
    'Stream',
    'Reader',
    'Builder',
    'Signer',
    'load_settings',
    'format_embeddable',
    'version',
    'sdk_version'
]
